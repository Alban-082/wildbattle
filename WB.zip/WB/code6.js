gdjs.InventoryCode = {};
gdjs.InventoryCode.GDPlayerObjects1= [];
gdjs.InventoryCode.GDPlayerObjects2= [];
gdjs.InventoryCode.GDPlayerObjects3= [];
gdjs.InventoryCode.GDGunObjects1= [];
gdjs.InventoryCode.GDGunObjects2= [];
gdjs.InventoryCode.GDGunObjects3= [];
gdjs.InventoryCode.GDNewSpriteObjects1= [];
gdjs.InventoryCode.GDNewSpriteObjects2= [];
gdjs.InventoryCode.GDNewSpriteObjects3= [];
gdjs.InventoryCode.GDGrassBorder3Objects1= [];
gdjs.InventoryCode.GDGrassBorder3Objects2= [];
gdjs.InventoryCode.GDGrassBorder3Objects3= [];
gdjs.InventoryCode.GDNewSprite2Objects1= [];
gdjs.InventoryCode.GDNewSprite2Objects2= [];
gdjs.InventoryCode.GDNewSprite2Objects3= [];
gdjs.InventoryCode.GDheaderObjects1= [];
gdjs.InventoryCode.GDheaderObjects2= [];
gdjs.InventoryCode.GDheaderObjects3= [];
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1= [];
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects2= [];
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects3= [];
gdjs.InventoryCode.GDSkinSliderObjects1= [];
gdjs.InventoryCode.GDSkinSliderObjects2= [];
gdjs.InventoryCode.GDSkinSliderObjects3= [];
gdjs.InventoryCode.GDGunSliderObjects1= [];
gdjs.InventoryCode.GDGunSliderObjects2= [];
gdjs.InventoryCode.GDGunSliderObjects3= [];
gdjs.InventoryCode.GDJohnObjects1= [];
gdjs.InventoryCode.GDJohnObjects2= [];
gdjs.InventoryCode.GDJohnObjects3= [];
gdjs.InventoryCode.GDDefaultObjects1= [];
gdjs.InventoryCode.GDDefaultObjects2= [];
gdjs.InventoryCode.GDDefaultObjects3= [];
gdjs.InventoryCode.GDNewTiledSpriteObjects1= [];
gdjs.InventoryCode.GDNewTiledSpriteObjects2= [];
gdjs.InventoryCode.GDNewTiledSpriteObjects3= [];


gdjs.InventoryCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlackSquareDecoratedButton"), gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1[k] = gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}}

}


};gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects1});
gdjs.InventoryCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 9 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("Run-1.png");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 9 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 81 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("John.png");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "Run-1.png" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("default");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "Run-1.png" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("default");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "John.png" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("john");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("RunJohn");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects1[i].getBehavior("Animation").getAnimationName() == "John.png" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects1[k] = gdjs.InventoryCode.GDDefaultObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("john");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("RunJohn");
}
}}

}


};gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects1});
gdjs.InventoryCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "knight-slot1.png" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("knight");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("knight.png");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 82 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 7 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("knight-slot1.png");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects1[i].getBehavior("Animation").getAnimationName() == "knight-slot1.png" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects1[k] = gdjs.InventoryCode.GDDefaultObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("knight");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("knight.png");
}
}}

}


};gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects1});
gdjs.InventoryCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "gigachad" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("sigma");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("sigma");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 9 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 156 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) == 1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("gigachad");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects1[i].getBehavior("Animation").getAnimationName() == "gigachad" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects1[k] = gdjs.InventoryCode.GDDefaultObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("sigma");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("sigma");
}
}}

}


};gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects1});
gdjs.InventoryCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "Coco" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("coco");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("ChickenSprite");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 228 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 82 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) == 1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("Coco");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects1[i].getBehavior("Animation").getAnimationName() == "Coco" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects1[k] = gdjs.InventoryCode.GDDefaultObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("coco");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("ChickenSprite");
}
}}

}


};gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects1});
gdjs.InventoryCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "Suspectguyslot" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Suspectguy");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Suspectguy");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 155 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 7 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("Suspectguyslot");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects1[i].getBehavior("Animation").getAnimationName() == "Suspectguyslot" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects1[k] = gdjs.InventoryCode.GDDefaultObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Suspectguy");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Suspectguy");
}
}}

}


};gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects2});
gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects = Hashtable.newFrom({"Default": gdjs.InventoryCode.GDDefaultObjects1});
gdjs.InventoryCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").getAnimationName() == "Buisnessman" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Buisnessman");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Buisnessman1");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getY() == 227 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects2.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects2[i].getX() == 7 ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects2[k] = gdjs.InventoryCode.GDDefaultObjects2[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) == 1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.InventoryCode.GDDefaultObjects2 */
{for(var i = 0, len = gdjs.InventoryCode.GDDefaultObjects2.length ;i < len;++i) {
    gdjs.InventoryCode.GDDefaultObjects2[i].getBehavior("Animation").setAnimationName("Buisnessman");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Default"), gdjs.InventoryCode.GDDefaultObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.InventoryCode.mapOfGDgdjs_9546InventoryCode_9546GDDefaultObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.InventoryCode.GDDefaultObjects1.length;i<l;++i) {
    if ( gdjs.InventoryCode.GDDefaultObjects1[i].getBehavior("Animation").getAnimationName() == "Buisnessman" ) {
        isConditionTrue_0 = true;
        gdjs.InventoryCode.GDDefaultObjects1[k] = gdjs.InventoryCode.GDDefaultObjects1[i];
        ++k;
    }
}
gdjs.InventoryCode.GDDefaultObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setString("Buisnessman");
}{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Buisnessman1");
}
}}

}


};gdjs.InventoryCode.eventsList7 = function(runtimeScene) {

{


gdjs.InventoryCode.eventsList0(runtimeScene);
}


{


gdjs.InventoryCode.eventsList1(runtimeScene);
}


{


gdjs.InventoryCode.eventsList2(runtimeScene);
}


{


gdjs.InventoryCode.eventsList3(runtimeScene);
}


{


gdjs.InventoryCode.eventsList4(runtimeScene);
}


{


gdjs.InventoryCode.eventsList5(runtimeScene);
}


{


gdjs.InventoryCode.eventsList6(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackSquareDecoratedButton"), gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1);
{for(var i = 0, len = gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1[i].SetLabelText("Retourner au menu", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackSquareDecoratedButton"), gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1);
{for(var i = 0, len = gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1[i].SetLabelText("Back to menu", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "coco";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.InventoryCode.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Resizable").setSize(280, 280);
}
}{for(var i = 0, len = gdjs.InventoryCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDGunObjects1[i].getBehavior("Animation").setAnimationName("disabled");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "coco");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.InventoryCode.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.InventoryCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.InventoryCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDPlayerObjects1[i].getBehavior("Resizable").setSize(193, 259);
}
}{for(var i = 0, len = gdjs.InventoryCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.InventoryCode.GDGunObjects1[i].getBehavior("Animation").setAnimationName("Gun13");
}
}}

}


};

gdjs.InventoryCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.InventoryCode.GDPlayerObjects1.length = 0;
gdjs.InventoryCode.GDPlayerObjects2.length = 0;
gdjs.InventoryCode.GDPlayerObjects3.length = 0;
gdjs.InventoryCode.GDGunObjects1.length = 0;
gdjs.InventoryCode.GDGunObjects2.length = 0;
gdjs.InventoryCode.GDGunObjects3.length = 0;
gdjs.InventoryCode.GDNewSpriteObjects1.length = 0;
gdjs.InventoryCode.GDNewSpriteObjects2.length = 0;
gdjs.InventoryCode.GDNewSpriteObjects3.length = 0;
gdjs.InventoryCode.GDGrassBorder3Objects1.length = 0;
gdjs.InventoryCode.GDGrassBorder3Objects2.length = 0;
gdjs.InventoryCode.GDGrassBorder3Objects3.length = 0;
gdjs.InventoryCode.GDNewSprite2Objects1.length = 0;
gdjs.InventoryCode.GDNewSprite2Objects2.length = 0;
gdjs.InventoryCode.GDNewSprite2Objects3.length = 0;
gdjs.InventoryCode.GDheaderObjects1.length = 0;
gdjs.InventoryCode.GDheaderObjects2.length = 0;
gdjs.InventoryCode.GDheaderObjects3.length = 0;
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects1.length = 0;
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects2.length = 0;
gdjs.InventoryCode.GDBlackSquareDecoratedButtonObjects3.length = 0;
gdjs.InventoryCode.GDSkinSliderObjects1.length = 0;
gdjs.InventoryCode.GDSkinSliderObjects2.length = 0;
gdjs.InventoryCode.GDSkinSliderObjects3.length = 0;
gdjs.InventoryCode.GDGunSliderObjects1.length = 0;
gdjs.InventoryCode.GDGunSliderObjects2.length = 0;
gdjs.InventoryCode.GDGunSliderObjects3.length = 0;
gdjs.InventoryCode.GDJohnObjects1.length = 0;
gdjs.InventoryCode.GDJohnObjects2.length = 0;
gdjs.InventoryCode.GDJohnObjects3.length = 0;
gdjs.InventoryCode.GDDefaultObjects1.length = 0;
gdjs.InventoryCode.GDDefaultObjects2.length = 0;
gdjs.InventoryCode.GDDefaultObjects3.length = 0;
gdjs.InventoryCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.InventoryCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.InventoryCode.GDNewTiledSpriteObjects3.length = 0;

gdjs.InventoryCode.eventsList7(runtimeScene);

return;

}

gdjs['InventoryCode'] = gdjs.InventoryCode;
