gdjs.Safe_45ChestCode = {};
gdjs.Safe_45ChestCode.GDNewSprite2Objects1= [];
gdjs.Safe_45ChestCode.GDNewSprite2Objects2= [];
gdjs.Safe_45ChestCode.GDNewSprite2Objects3= [];
gdjs.Safe_45ChestCode.GDCounterObjects1= [];
gdjs.Safe_45ChestCode.GDCounterObjects2= [];
gdjs.Safe_45ChestCode.GDCounterObjects3= [];
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1= [];
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects2= [];
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects3= [];
gdjs.Safe_45ChestCode.GDNewSprite3Objects1= [];
gdjs.Safe_45ChestCode.GDNewSprite3Objects2= [];
gdjs.Safe_45ChestCode.GDNewSprite3Objects3= [];
gdjs.Safe_45ChestCode.GDNewText2Objects1= [];
gdjs.Safe_45ChestCode.GDNewText2Objects2= [];
gdjs.Safe_45ChestCode.GDNewText2Objects3= [];
gdjs.Safe_45ChestCode.GDNewSprite4Objects1= [];
gdjs.Safe_45ChestCode.GDNewSprite4Objects2= [];
gdjs.Safe_45ChestCode.GDNewSprite4Objects3= [];
gdjs.Safe_45ChestCode.GDNewSpriteObjects1= [];
gdjs.Safe_45ChestCode.GDNewSpriteObjects2= [];
gdjs.Safe_45ChestCode.GDNewSpriteObjects3= [];
gdjs.Safe_45ChestCode.GDOnScreenControlsButtonObjects1= [];
gdjs.Safe_45ChestCode.GDOnScreenControlsButtonObjects2= [];
gdjs.Safe_45ChestCode.GDOnScreenControlsButtonObjects3= [];
gdjs.Safe_45ChestCode.GDNewSprite5Objects1= [];
gdjs.Safe_45ChestCode.GDNewSprite5Objects2= [];
gdjs.Safe_45ChestCode.GDNewSprite5Objects3= [];
gdjs.Safe_45ChestCode.GDNewSprite6Objects1= [];
gdjs.Safe_45ChestCode.GDNewSprite6Objects2= [];
gdjs.Safe_45ChestCode.GDNewSprite6Objects3= [];
gdjs.Safe_45ChestCode.GDDefaultObjects1= [];
gdjs.Safe_45ChestCode.GDDefaultObjects2= [];
gdjs.Safe_45ChestCode.GDDefaultObjects3= [];
gdjs.Safe_45ChestCode.GDJohnObjects1= [];
gdjs.Safe_45ChestCode.GDJohnObjects2= [];
gdjs.Safe_45ChestCode.GDJohnObjects3= [];
gdjs.Safe_45ChestCode.GDNewText3Objects1= [];
gdjs.Safe_45ChestCode.GDNewText3Objects2= [];
gdjs.Safe_45ChestCode.GDNewText3Objects3= [];
gdjs.Safe_45ChestCode.GDYesObjects1= [];
gdjs.Safe_45ChestCode.GDYesObjects2= [];
gdjs.Safe_45ChestCode.GDYesObjects3= [];
gdjs.Safe_45ChestCode.GDNoObjects1= [];
gdjs.Safe_45ChestCode.GDNoObjects2= [];
gdjs.Safe_45ChestCode.GDNoObjects3= [];
gdjs.Safe_45ChestCode.GDOrangeBubbleButtonObjects1= [];
gdjs.Safe_45ChestCode.GDOrangeBubbleButtonObjects2= [];
gdjs.Safe_45ChestCode.GDOrangeBubbleButtonObjects3= [];
gdjs.Safe_45ChestCode.GDknightObjects1= [];
gdjs.Safe_45ChestCode.GDknightObjects2= [];
gdjs.Safe_45ChestCode.GDknightObjects3= [];
gdjs.Safe_45ChestCode.GDcommon_9595priceObjects1= [];
gdjs.Safe_45ChestCode.GDcommon_9595priceObjects2= [];
gdjs.Safe_45ChestCode.GDcommon_9595priceObjects3= [];
gdjs.Safe_45ChestCode.GDrare_9595priceObjects1= [];
gdjs.Safe_45ChestCode.GDrare_9595priceObjects2= [];
gdjs.Safe_45ChestCode.GDrare_9595priceObjects3= [];
gdjs.Safe_45ChestCode.GDepic_9595priceObjects1= [];
gdjs.Safe_45ChestCode.GDepic_9595priceObjects2= [];
gdjs.Safe_45ChestCode.GDepic_9595priceObjects3= [];
gdjs.Safe_45ChestCode.GDlegendary_9595priceObjects1= [];
gdjs.Safe_45ChestCode.GDlegendary_9595priceObjects2= [];
gdjs.Safe_45ChestCode.GDlegendary_9595priceObjects3= [];
gdjs.Safe_45ChestCode.GDGigachadObjects1= [];
gdjs.Safe_45ChestCode.GDGigachadObjects2= [];
gdjs.Safe_45ChestCode.GDGigachadObjects3= [];
gdjs.Safe_45ChestCode.GDsuspectguyObjects1= [];
gdjs.Safe_45ChestCode.GDsuspectguyObjects2= [];
gdjs.Safe_45ChestCode.GDsuspectguyObjects3= [];
gdjs.Safe_45ChestCode.GDbuisnessmanObjects1= [];
gdjs.Safe_45ChestCode.GDbuisnessmanObjects2= [];
gdjs.Safe_45ChestCode.GDbuisnessmanObjects3= [];
gdjs.Safe_45ChestCode.GDLegendary_9595_9595_9595Objects1= [];
gdjs.Safe_45ChestCode.GDLegendary_9595_9595_9595Objects2= [];
gdjs.Safe_45ChestCode.GDLegendary_9595_9595_9595Objects3= [];
gdjs.Safe_45ChestCode.GDBGObjects1= [];
gdjs.Safe_45ChestCode.GDBGObjects2= [];
gdjs.Safe_45ChestCode.GDBGObjects3= [];
gdjs.Safe_45ChestCode.GDCodeInputObjects1= [];
gdjs.Safe_45ChestCode.GDCodeInputObjects2= [];
gdjs.Safe_45ChestCode.GDCodeInputObjects3= [];
gdjs.Safe_45ChestCode.GDvalidationObjects1= [];
gdjs.Safe_45ChestCode.GDvalidationObjects2= [];
gdjs.Safe_45ChestCode.GDvalidationObjects3= [];
gdjs.Safe_45ChestCode.GDSuccessObjects1= [];
gdjs.Safe_45ChestCode.GDSuccessObjects2= [];
gdjs.Safe_45ChestCode.GDSuccessObjects3= [];
gdjs.Safe_45ChestCode.GDIceShatter2Objects1= [];
gdjs.Safe_45ChestCode.GDIceShatter2Objects2= [];
gdjs.Safe_45ChestCode.GDIceShatter2Objects3= [];
gdjs.Safe_45ChestCode.GDNewPanelSpriteObjects1= [];
gdjs.Safe_45ChestCode.GDNewPanelSpriteObjects2= [];
gdjs.Safe_45ChestCode.GDNewPanelSpriteObjects3= [];


gdjs.Safe_45ChestCode.eventsList0 = function(runtimeScene) {

};gdjs.Safe_45ChestCode.asyncCallback35624460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Succes");
}{runtimeScene.getGame().getVariables().getFromIndex(7).setString("0");
}}
gdjs.Safe_45ChestCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Safe_45ChestCode.asyncCallback35624460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Safe_45ChestCode.asyncCallback35631732 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Succes");
}}
gdjs.Safe_45ChestCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Safe_45ChestCode.asyncCallback35631732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Safe_45ChestCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)) == "uselessarmor";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Score", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "knight", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Succes");
}
{ //Subevents
gdjs.Safe_45ChestCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Safe_45ChestCode.asyncCallback35633340 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Safe_45ChestCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Safe_45ChestCode.asyncCallback35633340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Safe_45ChestCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)) == "t1m31sM0n3y";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Score", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Buisnessman", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Succes");
}
{ //Subevents
gdjs.Safe_45ChestCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Safe_45ChestCode.asyncCallback35635020 = function (runtimeScene, asyncObjectsList) {
}
gdjs.Safe_45ChestCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Safe_45ChestCode.asyncCallback35635020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Safe_45ChestCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)) == "iswitchthelightsoff!";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Score", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Suspectguy", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Succes");
}
{ //Subevents
gdjs.Safe_45ChestCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Safe_45ChestCode.asyncCallback35636804 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Succes");
}}
gdjs.Safe_45ChestCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Safe_45ChestCode.asyncCallback35636804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Safe_45ChestCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)) == "john4u";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Scores", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "John", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Succes");
}
{ //Subevents
gdjs.Safe_45ChestCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Safe_45ChestCode.asyncCallback35637668 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Succes");
}}
gdjs.Safe_45ChestCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.Safe_45ChestCode.asyncCallback35637668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Safe_45ChestCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)) == "gotogym";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Gigachad", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9))));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Succes");
}
{ //Subevents
gdjs.Safe_45ChestCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Safe_45ChestCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)) == "06/04/2024";
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Scores", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "coco", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Succes");
}}

}


};gdjs.Safe_45ChestCode.eventsList13 = function(runtimeScene) {

{


gdjs.Safe_45ChestCode.eventsList3(runtimeScene);
}


{


gdjs.Safe_45ChestCode.eventsList5(runtimeScene);
}


{


gdjs.Safe_45ChestCode.eventsList7(runtimeScene);
}


{


gdjs.Safe_45ChestCode.eventsList9(runtimeScene);
}


{


gdjs.Safe_45ChestCode.eventsList11(runtimeScene);
}


{


gdjs.Safe_45ChestCode.eventsList12(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Success"), gdjs.Safe_45ChestCode.GDSuccessObjects2);
{for(var i = 0, len = gdjs.Safe_45ChestCode.GDSuccessObjects2.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDSuccessObjects2[i].setOutlineEnabled(true);
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDSuccessObjects2.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDSuccessObjects2[i].setOutlineColor("80;227;194");
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDSuccessObjects2.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDSuccessObjects2[i].setOutlineThickness(5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("validation"), gdjs.Safe_45ChestCode.GDvalidationObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Safe_45ChestCode.GDvalidationObjects1.length;i<l;++i) {
    if ( gdjs.Safe_45ChestCode.GDvalidationObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Safe_45ChestCode.GDvalidationObjects1[k] = gdjs.Safe_45ChestCode.GDvalidationObjects1[i];
        ++k;
    }
}
gdjs.Safe_45ChestCode.GDvalidationObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CodeInput"), gdjs.Safe_45ChestCode.GDCodeInputObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(7).setString((( gdjs.Safe_45ChestCode.GDCodeInputObjects1.length === 0 ) ? "" :gdjs.Safe_45ChestCode.GDCodeInputObjects1[0].getText()));
}}

}


};gdjs.Safe_45ChestCode.eventsList14 = function(runtimeScene) {

{


gdjs.Safe_45ChestCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Succes");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Safe_45ChestCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("No"), gdjs.Safe_45ChestCode.GDNoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Safe_45ChestCode.GDNoObjects1.length;i<l;++i) {
    if ( gdjs.Safe_45ChestCode.GDNoObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Safe_45ChestCode.GDNoObjects1[k] = gdjs.Safe_45ChestCode.GDNoObjects1[i];
        ++k;
    }
}
gdjs.Safe_45ChestCode.GDNoObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Confirmation");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Confirmation");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackToMenuButton"), gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1.length;i<l;++i) {
    if ( gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1[k] = gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1[i];
        ++k;
    }
}
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BackToMenuButton"), gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Success"), gdjs.Safe_45ChestCode.GDSuccessObjects1);
gdjs.copyArray(runtimeScene.getObjects("validation"), gdjs.Safe_45ChestCode.GDvalidationObjects1);
{for(var i = 0, len = gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1[i].SetLabelText("Retourner au menu", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDSuccessObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDSuccessObjects1[i].getBehavior("Text").setText("Succès");
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDvalidationObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDvalidationObjects1[i].SetLabelText("valider", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BackToMenuButton"), gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Success"), gdjs.Safe_45ChestCode.GDSuccessObjects1);
gdjs.copyArray(runtimeScene.getObjects("Yes"), gdjs.Safe_45ChestCode.GDYesObjects1);
gdjs.copyArray(runtimeScene.getObjects("validation"), gdjs.Safe_45ChestCode.GDvalidationObjects1);
{for(var i = 0, len = gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1[i].SetLabelText("Back to menu", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDSuccessObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDSuccessObjects1[i].getBehavior("Text").setText("Success");
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDvalidationObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDvalidationObjects1[i].SetLabelText("Test code", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Safe_45ChestCode.GDYesObjects1.length ;i < len;++i) {
    gdjs.Safe_45ChestCode.GDYesObjects1[i].SetLabelText("Yes", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


gdjs.Safe_45ChestCode.eventsList13(runtimeScene);
}


};

gdjs.Safe_45ChestCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Safe_45ChestCode.GDNewSprite2Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite2Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite2Objects3.length = 0;
gdjs.Safe_45ChestCode.GDCounterObjects1.length = 0;
gdjs.Safe_45ChestCode.GDCounterObjects2.length = 0;
gdjs.Safe_45ChestCode.GDCounterObjects3.length = 0;
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects1.length = 0;
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects2.length = 0;
gdjs.Safe_45ChestCode.GDBackToMenuButtonObjects3.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite3Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite3Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite3Objects3.length = 0;
gdjs.Safe_45ChestCode.GDNewText2Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewText2Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewText2Objects3.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite4Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite4Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite4Objects3.length = 0;
gdjs.Safe_45ChestCode.GDNewSpriteObjects1.length = 0;
gdjs.Safe_45ChestCode.GDNewSpriteObjects2.length = 0;
gdjs.Safe_45ChestCode.GDNewSpriteObjects3.length = 0;
gdjs.Safe_45ChestCode.GDOnScreenControlsButtonObjects1.length = 0;
gdjs.Safe_45ChestCode.GDOnScreenControlsButtonObjects2.length = 0;
gdjs.Safe_45ChestCode.GDOnScreenControlsButtonObjects3.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite5Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite5Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite5Objects3.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite6Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite6Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewSprite6Objects3.length = 0;
gdjs.Safe_45ChestCode.GDDefaultObjects1.length = 0;
gdjs.Safe_45ChestCode.GDDefaultObjects2.length = 0;
gdjs.Safe_45ChestCode.GDDefaultObjects3.length = 0;
gdjs.Safe_45ChestCode.GDJohnObjects1.length = 0;
gdjs.Safe_45ChestCode.GDJohnObjects2.length = 0;
gdjs.Safe_45ChestCode.GDJohnObjects3.length = 0;
gdjs.Safe_45ChestCode.GDNewText3Objects1.length = 0;
gdjs.Safe_45ChestCode.GDNewText3Objects2.length = 0;
gdjs.Safe_45ChestCode.GDNewText3Objects3.length = 0;
gdjs.Safe_45ChestCode.GDYesObjects1.length = 0;
gdjs.Safe_45ChestCode.GDYesObjects2.length = 0;
gdjs.Safe_45ChestCode.GDYesObjects3.length = 0;
gdjs.Safe_45ChestCode.GDNoObjects1.length = 0;
gdjs.Safe_45ChestCode.GDNoObjects2.length = 0;
gdjs.Safe_45ChestCode.GDNoObjects3.length = 0;
gdjs.Safe_45ChestCode.GDOrangeBubbleButtonObjects1.length = 0;
gdjs.Safe_45ChestCode.GDOrangeBubbleButtonObjects2.length = 0;
gdjs.Safe_45ChestCode.GDOrangeBubbleButtonObjects3.length = 0;
gdjs.Safe_45ChestCode.GDknightObjects1.length = 0;
gdjs.Safe_45ChestCode.GDknightObjects2.length = 0;
gdjs.Safe_45ChestCode.GDknightObjects3.length = 0;
gdjs.Safe_45ChestCode.GDcommon_9595priceObjects1.length = 0;
gdjs.Safe_45ChestCode.GDcommon_9595priceObjects2.length = 0;
gdjs.Safe_45ChestCode.GDcommon_9595priceObjects3.length = 0;
gdjs.Safe_45ChestCode.GDrare_9595priceObjects1.length = 0;
gdjs.Safe_45ChestCode.GDrare_9595priceObjects2.length = 0;
gdjs.Safe_45ChestCode.GDrare_9595priceObjects3.length = 0;
gdjs.Safe_45ChestCode.GDepic_9595priceObjects1.length = 0;
gdjs.Safe_45ChestCode.GDepic_9595priceObjects2.length = 0;
gdjs.Safe_45ChestCode.GDepic_9595priceObjects3.length = 0;
gdjs.Safe_45ChestCode.GDlegendary_9595priceObjects1.length = 0;
gdjs.Safe_45ChestCode.GDlegendary_9595priceObjects2.length = 0;
gdjs.Safe_45ChestCode.GDlegendary_9595priceObjects3.length = 0;
gdjs.Safe_45ChestCode.GDGigachadObjects1.length = 0;
gdjs.Safe_45ChestCode.GDGigachadObjects2.length = 0;
gdjs.Safe_45ChestCode.GDGigachadObjects3.length = 0;
gdjs.Safe_45ChestCode.GDsuspectguyObjects1.length = 0;
gdjs.Safe_45ChestCode.GDsuspectguyObjects2.length = 0;
gdjs.Safe_45ChestCode.GDsuspectguyObjects3.length = 0;
gdjs.Safe_45ChestCode.GDbuisnessmanObjects1.length = 0;
gdjs.Safe_45ChestCode.GDbuisnessmanObjects2.length = 0;
gdjs.Safe_45ChestCode.GDbuisnessmanObjects3.length = 0;
gdjs.Safe_45ChestCode.GDLegendary_9595_9595_9595Objects1.length = 0;
gdjs.Safe_45ChestCode.GDLegendary_9595_9595_9595Objects2.length = 0;
gdjs.Safe_45ChestCode.GDLegendary_9595_9595_9595Objects3.length = 0;
gdjs.Safe_45ChestCode.GDBGObjects1.length = 0;
gdjs.Safe_45ChestCode.GDBGObjects2.length = 0;
gdjs.Safe_45ChestCode.GDBGObjects3.length = 0;
gdjs.Safe_45ChestCode.GDCodeInputObjects1.length = 0;
gdjs.Safe_45ChestCode.GDCodeInputObjects2.length = 0;
gdjs.Safe_45ChestCode.GDCodeInputObjects3.length = 0;
gdjs.Safe_45ChestCode.GDvalidationObjects1.length = 0;
gdjs.Safe_45ChestCode.GDvalidationObjects2.length = 0;
gdjs.Safe_45ChestCode.GDvalidationObjects3.length = 0;
gdjs.Safe_45ChestCode.GDSuccessObjects1.length = 0;
gdjs.Safe_45ChestCode.GDSuccessObjects2.length = 0;
gdjs.Safe_45ChestCode.GDSuccessObjects3.length = 0;
gdjs.Safe_45ChestCode.GDIceShatter2Objects1.length = 0;
gdjs.Safe_45ChestCode.GDIceShatter2Objects2.length = 0;
gdjs.Safe_45ChestCode.GDIceShatter2Objects3.length = 0;
gdjs.Safe_45ChestCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.Safe_45ChestCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.Safe_45ChestCode.GDNewPanelSpriteObjects3.length = 0;

gdjs.Safe_45ChestCode.eventsList14(runtimeScene);

return;

}

gdjs['Safe_45ChestCode'] = gdjs.Safe_45ChestCode;
