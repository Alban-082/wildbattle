gdjs.Wildbattle_32SurvivalistCode = {};
gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDConnectObjects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDConnectObjects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDtitleObjects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDtitleObjects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDtitle2Objects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDtitle2Objects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDNewSpriteObjects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDNewSpriteObjects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDNewSprite2Objects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDNewSprite2Objects2= [];
gdjs.Wildbattle_32SurvivalistCode.GDNewTiledSpriteObjects1= [];
gdjs.Wildbattle_32SurvivalistCode.GDNewTiledSpriteObjects2= [];


gdjs.Wildbattle_32SurvivalistCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("QuitButton"), gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1.length;i<l;++i) {
    if ( gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1[k] = gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1[i];
        ++k;
    }
}
gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hosting"), gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1.length;i<l;++i) {
    if ( gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1[k] = gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1[i];
        ++k;
    }
}
gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainGame3", false);
}}

}


};

gdjs.Wildbattle_32SurvivalistCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDHostingObjects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDConnectObjects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDConnectObjects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDtitleObjects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDtitleObjects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDtitle2Objects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDtitle2Objects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDQuitButtonObjects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDNewSpriteObjects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDNewSpriteObjects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDNewSprite2Objects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDNewSprite2Objects2.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Wildbattle_32SurvivalistCode.GDNewTiledSpriteObjects2.length = 0;

gdjs.Wildbattle_32SurvivalistCode.eventsList0(runtimeScene);

return;

}

gdjs['Wildbattle_32SurvivalistCode'] = gdjs.Wildbattle_32SurvivalistCode;
