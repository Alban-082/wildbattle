gdjs.StartMenuCode = {};
gdjs.StartMenuCode.GDPlayerObjects1= [];
gdjs.StartMenuCode.GDPlayerObjects2= [];
gdjs.StartMenuCode.GDPlayerObjects3= [];
gdjs.StartMenuCode.GDNewSpriteObjects1= [];
gdjs.StartMenuCode.GDNewSpriteObjects2= [];
gdjs.StartMenuCode.GDNewSpriteObjects3= [];
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1= [];
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2= [];
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects3= [];
gdjs.StartMenuCode.GDRankedModeObjects1= [];
gdjs.StartMenuCode.GDRankedModeObjects2= [];
gdjs.StartMenuCode.GDRankedModeObjects3= [];
gdjs.StartMenuCode.GDgrassObjects1= [];
gdjs.StartMenuCode.GDgrassObjects2= [];
gdjs.StartMenuCode.GDgrassObjects3= [];
gdjs.StartMenuCode.GDRankedTitleObjects1= [];
gdjs.StartMenuCode.GDRankedTitleObjects2= [];
gdjs.StartMenuCode.GDRankedTitleObjects3= [];
gdjs.StartMenuCode.GDNewVideoObjects1= [];
gdjs.StartMenuCode.GDNewVideoObjects2= [];
gdjs.StartMenuCode.GDNewVideoObjects3= [];
gdjs.StartMenuCode.GDGoldSquareToggleObjects1= [];
gdjs.StartMenuCode.GDGoldSquareToggleObjects2= [];
gdjs.StartMenuCode.GDGoldSquareToggleObjects3= [];
gdjs.StartMenuCode.GDFelSpellObjects1= [];
gdjs.StartMenuCode.GDFelSpellObjects2= [];
gdjs.StartMenuCode.GDFelSpellObjects3= [];
gdjs.StartMenuCode.GDLeaderboardObjects1= [];
gdjs.StartMenuCode.GDLeaderboardObjects2= [];
gdjs.StartMenuCode.GDLeaderboardObjects3= [];
gdjs.StartMenuCode.GDGoldRoundToggleObjects1= [];
gdjs.StartMenuCode.GDGoldRoundToggleObjects2= [];
gdjs.StartMenuCode.GDGoldRoundToggleObjects3= [];
gdjs.StartMenuCode.GDProtectionCircleObjects1= [];
gdjs.StartMenuCode.GDProtectionCircleObjects2= [];
gdjs.StartMenuCode.GDProtectionCircleObjects3= [];
gdjs.StartMenuCode.GDheaderObjects1= [];
gdjs.StartMenuCode.GDheaderObjects2= [];
gdjs.StartMenuCode.GDheaderObjects3= [];
gdjs.StartMenuCode.GDWallObjects1= [];
gdjs.StartMenuCode.GDWallObjects2= [];
gdjs.StartMenuCode.GDWallObjects3= [];
gdjs.StartMenuCode.GDTreeObjects1= [];
gdjs.StartMenuCode.GDTreeObjects2= [];
gdjs.StartMenuCode.GDTreeObjects3= [];
gdjs.StartMenuCode.GDInvetoryObjects1= [];
gdjs.StartMenuCode.GDInvetoryObjects2= [];
gdjs.StartMenuCode.GDInvetoryObjects3= [];
gdjs.StartMenuCode.GDGameObjects1= [];
gdjs.StartMenuCode.GDGameObjects2= [];
gdjs.StartMenuCode.GDGameObjects3= [];
gdjs.StartMenuCode.GDSettings2Objects1= [];
gdjs.StartMenuCode.GDSettings2Objects2= [];
gdjs.StartMenuCode.GDSettings2Objects3= [];
gdjs.StartMenuCode.GDShopObjects1= [];
gdjs.StartMenuCode.GDShopObjects2= [];
gdjs.StartMenuCode.GDShopObjects3= [];
gdjs.StartMenuCode.GDNewSprite2Objects1= [];
gdjs.StartMenuCode.GDNewSprite2Objects2= [];
gdjs.StartMenuCode.GDNewSprite2Objects3= [];
gdjs.StartMenuCode.GDNewButtonObjects1= [];
gdjs.StartMenuCode.GDNewButtonObjects2= [];
gdjs.StartMenuCode.GDNewButtonObjects3= [];
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1= [];
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2= [];
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects3= [];
gdjs.StartMenuCode.GDFullscreenObjects1= [];
gdjs.StartMenuCode.GDFullscreenObjects2= [];
gdjs.StartMenuCode.GDFullscreenObjects3= [];
gdjs.StartMenuCode.GDNewButton2Objects1= [];
gdjs.StartMenuCode.GDNewButton2Objects2= [];
gdjs.StartMenuCode.GDNewButton2Objects3= [];
gdjs.StartMenuCode.GDSquareWhiteSliderObjects1= [];
gdjs.StartMenuCode.GDSquareWhiteSliderObjects2= [];
gdjs.StartMenuCode.GDSquareWhiteSliderObjects3= [];
gdjs.StartMenuCode.GDSoundObjects1= [];
gdjs.StartMenuCode.GDSoundObjects2= [];
gdjs.StartMenuCode.GDSoundObjects3= [];
gdjs.StartMenuCode.GDNewButton3Objects1= [];
gdjs.StartMenuCode.GDNewButton3Objects2= [];
gdjs.StartMenuCode.GDNewButton3Objects3= [];
gdjs.StartMenuCode.GDFranceObjects1= [];
gdjs.StartMenuCode.GDFranceObjects2= [];
gdjs.StartMenuCode.GDFranceObjects3= [];
gdjs.StartMenuCode.GDUsaObjects1= [];
gdjs.StartMenuCode.GDUsaObjects2= [];
gdjs.StartMenuCode.GDUsaObjects3= [];
gdjs.StartMenuCode.GDLanguageObjects1= [];
gdjs.StartMenuCode.GDLanguageObjects2= [];
gdjs.StartMenuCode.GDLanguageObjects3= [];
gdjs.StartMenuCode.GDNewTiledSpriteObjects1= [];
gdjs.StartMenuCode.GDNewTiledSpriteObjects2= [];
gdjs.StartMenuCode.GDNewTiledSpriteObjects3= [];
gdjs.StartMenuCode.GDdiscordlinkObjects1= [];
gdjs.StartMenuCode.GDdiscordlinkObjects2= [];
gdjs.StartMenuCode.GDdiscordlinkObjects3= [];
gdjs.StartMenuCode.GDNewTextObjects1= [];
gdjs.StartMenuCode.GDNewTextObjects2= [];
gdjs.StartMenuCode.GDNewTextObjects3= [];
gdjs.StartMenuCode.GDcameraObjects1= [];
gdjs.StartMenuCode.GDcameraObjects2= [];
gdjs.StartMenuCode.GDcameraObjects3= [];
gdjs.StartMenuCode.GDNewVideo2Objects1= [];
gdjs.StartMenuCode.GDNewVideo2Objects2= [];
gdjs.StartMenuCode.GDNewVideo2Objects3= [];


gdjs.StartMenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GoldRoundToggle"), gdjs.StartMenuCode.GDGoldRoundToggleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDGoldRoundToggleObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDGoldRoundToggleObjects1[i].HasJustBeenUnchecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDGoldRoundToggleObjects1[k] = gdjs.StartMenuCode.GDGoldRoundToggleObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDGoldRoundToggleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.StartMenuCode.GDGoldRoundToggleObjects1 */
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "05b26c61-c77e-4bad-b074-3f3060d6db57", false);
}{for(var i = 0, len = gdjs.StartMenuCode.GDGoldRoundToggleObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDGoldRoundToggleObjects1[i].SetChecked(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.StartMenuCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SquareWhiteSlider"), gdjs.StartMenuCode.GDSquareWhiteSliderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDSquareWhiteSliderObjects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDSquareWhiteSliderObjects2[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDSquareWhiteSliderObjects2[k] = gdjs.StartMenuCode.GDSquareWhiteSliderObjects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDSquareWhiteSliderObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Settings");
}
if (isConditionTrue_0) {
/* Reuse gdjs.StartMenuCode.GDSquareWhiteSliderObjects2 */
{gdjs.evtTools.sound.playMusic(runtimeScene, "PickUp.wav", false, (( gdjs.StartMenuCode.GDSquareWhiteSliderObjects2.length === 0 ) ? 0 :gdjs.StartMenuCode.GDSquareWhiteSliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SquareWhiteSlider"), gdjs.StartMenuCode.GDSquareWhiteSliderObjects2);
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, (( gdjs.StartMenuCode.GDSquareWhiteSliderObjects2.length === 0 ) ? 0 :gdjs.StartMenuCode.GDSquareWhiteSliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewButton2"), gdjs.StartMenuCode.GDNewButton2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDNewButton2Objects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDNewButton2Objects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDNewButton2Objects2[k] = gdjs.StartMenuCode.GDNewButton2Objects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDNewButton2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Settings");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Settings");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallGreenPlasticRoundSwitch"), gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2[i].HasJustBeenUnchecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2[k] = gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Settings");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, false, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings2"), gdjs.StartMenuCode.GDSettings2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDSettings2Objects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDSettings2Objects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDSettings2Objects2[k] = gdjs.StartMenuCode.GDSettings2Objects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDSettings2Objects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Settings");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallGreenPlasticRoundSwitch"), gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1[i].HasJustBeenChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1[k] = gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Settings");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}}

}


};gdjs.StartMenuCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Shop"), gdjs.StartMenuCode.GDShopObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDShopObjects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDShopObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDShopObjects2[k] = gdjs.StartMenuCode.GDShopObjects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDShopObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Safe-Chest", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Invetory"), gdjs.StartMenuCode.GDInvetoryObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDInvetoryObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDInvetoryObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDInvetoryObjects1[k] = gdjs.StartMenuCode.GDInvetoryObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDInvetoryObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Inventory", false);
}}

}


};gdjs.StartMenuCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.playerAuthentication.isAuthenticated());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.playerAuthentication.isAuthenticationWindowOpen());
}
if (isConditionTrue_0) {
{gdjs.playerAuthentication.openAuthenticationWindow(runtimeScene);
}}

}


};gdjs.StartMenuCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "Score", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(6));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6))), runtimeScene.getGame().getVariables().getFromIndex(0));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "John", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8))), runtimeScene.getGame().getVariables().getFromIndex(1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "sigma", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(12));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12))), runtimeScene.getGame().getVariables().getFromIndex(9));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "John", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(8));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8))), runtimeScene.getGame().getVariables().getFromIndex(1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "Buisnessman", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(10));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(10))), runtimeScene.getGame().getVariables().getFromIndex(6));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "Suspectguy", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(13));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13))), runtimeScene.getGame().getVariables().getFromIndex(4));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "knight", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(9));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9))), runtimeScene.getGame().getVariables().getFromIndex(3));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "coco", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(11));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11))), runtimeScene.getGame().getVariables().getFromIndex(8));
}}

}


};gdjs.StartMenuCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "coco";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.StartMenuCode.GDNewSpriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Coco");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDNewSpriteObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDNewSpriteObjects2[i].getBehavior("Resizable").setSize(0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "sigma";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("sigma");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "john";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("John.png");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "Buisnessman";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.StartMenuCode.GDNewSpriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Buisnessman1");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDNewSpriteObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDNewSpriteObjects2[i].getBehavior("Animation").setAnimationName("void");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "knight";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("knight.png");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "Suspectguy";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("gigachad");
}
}}

}


};gdjs.StartMenuCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("France"), gdjs.StartMenuCode.GDFranceObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDFranceObjects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDFranceObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDFranceObjects2[k] = gdjs.StartMenuCode.GDFranceObjects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDFranceObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Settings");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "lang", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Usa"), gdjs.StartMenuCode.GDUsaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDUsaObjects2.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDUsaObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDUsaObjects2[k] = gdjs.StartMenuCode.GDUsaObjects2[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDUsaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Settings");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), false);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "lang", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("API", "lang", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(5));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5))), runtimeScene.getGame().getVariables().getFromIndex(5));
}}

}


};gdjs.StartMenuCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fullscreen"), gdjs.StartMenuCode.GDFullscreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Invetory"), gdjs.StartMenuCode.GDInvetoryObjects1);
gdjs.copyArray(runtimeScene.getObjects("Language"), gdjs.StartMenuCode.GDLanguageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.StartMenuCode.GDLeaderboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("RankedTitle"), gdjs.StartMenuCode.GDRankedTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Settings2"), gdjs.StartMenuCode.GDSettings2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shop"), gdjs.StartMenuCode.GDShopObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sound"), gdjs.StartMenuCode.GDSoundObjects1);
gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1);
{for(var i = 0, len = gdjs.StartMenuCode.GDRankedTitleObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDRankedTitleObjects1[i].getBehavior("Text").setText("Classé");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDLeaderboardObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDLeaderboardObjects1[i].getBehavior("Text").setText("Classement");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDLanguageObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDLanguageObjects1[i].getBehavior("Text").setText("Langue :");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i].SetLabelText("Jouer", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDInvetoryObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDInvetoryObjects1[i].SetLabelText("Inventaire", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDSettings2Objects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDSettings2Objects1[i].SetLabelText("Paramettres", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDShopObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDShopObjects1[i].SetLabelText("Coffre-fort", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDFullscreenObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDFullscreenObjects1[i].getBehavior("Text").setText("Plein écrant");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDSoundObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDSoundObjects1[i].getBehavior("Text").setText("Volume");
}
}}

}


};gdjs.StartMenuCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fullscreen"), gdjs.StartMenuCode.GDFullscreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Invetory"), gdjs.StartMenuCode.GDInvetoryObjects1);
gdjs.copyArray(runtimeScene.getObjects("Language"), gdjs.StartMenuCode.GDLanguageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard"), gdjs.StartMenuCode.GDLeaderboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("RankedMode"), gdjs.StartMenuCode.GDRankedModeObjects1);
gdjs.copyArray(runtimeScene.getObjects("RankedTitle"), gdjs.StartMenuCode.GDRankedTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Settings2"), gdjs.StartMenuCode.GDSettings2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Shop"), gdjs.StartMenuCode.GDShopObjects1);
gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1);
{for(var i = 0, len = gdjs.StartMenuCode.GDRankedTitleObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDRankedTitleObjects1[i].getBehavior("Text").setText("Ranked");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDLanguageObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDLanguageObjects1[i].getBehavior("Text").setText("Language :");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDLeaderboardObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDLeaderboardObjects1[i].getBehavior("Text").setText("Leaderboard");
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i].SetLabelText("Play", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDRankedModeObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDRankedModeObjects1[i].SetLabelText("Play", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDInvetoryObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDInvetoryObjects1[i].SetLabelText("Inventory", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDSettings2Objects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDSettings2Objects1[i].SetLabelText("Settings", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDShopObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDShopObjects1[i].SetLabelText("Safe-chest", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.StartMenuCode.GDFullscreenObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDFullscreenObjects1[i].getBehavior("Text").setText("Fullscreen");
}
}}

}


};gdjs.StartMenuCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.StartMenuCode.GDPlayerObjects1.length !== 0 ? gdjs.StartMenuCode.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.StartMenuCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
if (isConditionTrue_0) {
/* Reuse gdjs.StartMenuCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.StartMenuCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDPlayerObjects1[i].playAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[k] = gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainGame", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GoldSquareToggle"), gdjs.StartMenuCode.GDGoldSquareToggleObjects1);
gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[k] = gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDGoldSquareToggleObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDGoldSquareToggleObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDGoldSquareToggleObjects1[k] = gdjs.StartMenuCode.GDGoldSquareToggleObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDGoldSquareToggleObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainGame2", false);
}}

}


{


gdjs.StartMenuCode.eventsList0(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList1(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList2(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("NewButton3"), gdjs.StartMenuCode.GDNewButton3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDNewButton3Objects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDNewButton3Objects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDNewButton3Objects1[k] = gdjs.StartMenuCode.GDNewButton3Objects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDNewButton3Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.playerAuthentication.logout(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("API", "Score", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.readStringFromJSONFile("API", "Score", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(6));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6))), runtimeScene.getGame().getVariables().getFromIndex(0));
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.fileSystem.makeDirectory("API", gdjs.VariablesContainer.badVariable);
}}

}


{


gdjs.StartMenuCode.eventsList4(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList5(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList6(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList7(runtimeScene);
}


{


gdjs.StartMenuCode.eventsList8(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.input.showCursor(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "coco");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.StartMenuCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.StartMenuCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDNewSpriteObjects1[i].getBehavior("Resizable").setSize(118, 118);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "Buisnessman");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.StartMenuCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.StartMenuCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.StartMenuCode.GDNewSpriteObjects1[i].getBehavior("Animation").setAnimationName("Gun13");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("discordlink"), gdjs.StartMenuCode.GDdiscordlinkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDdiscordlinkObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDdiscordlinkObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDdiscordlinkObjects1[k] = gdjs.StartMenuCode.GDdiscordlinkObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDdiscordlinkObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://discord.gg/wnADuJut3X", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Game"), gdjs.StartMenuCode.GDGameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartMenuCode.GDGameObjects1.length;i<l;++i) {
    if ( gdjs.StartMenuCode.GDGameObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartMenuCode.GDGameObjects1[k] = gdjs.StartMenuCode.GDGameObjects1[i];
        ++k;
    }
}
gdjs.StartMenuCode.GDGameObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Wildbattle Survivalist", false);
}}

}


};

gdjs.StartMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.StartMenuCode.GDPlayerObjects1.length = 0;
gdjs.StartMenuCode.GDPlayerObjects2.length = 0;
gdjs.StartMenuCode.GDPlayerObjects3.length = 0;
gdjs.StartMenuCode.GDNewSpriteObjects1.length = 0;
gdjs.StartMenuCode.GDNewSpriteObjects2.length = 0;
gdjs.StartMenuCode.GDNewSpriteObjects3.length = 0;
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.StartMenuCode.GDTransparentButtonWithWhiteBlueBorderObjects3.length = 0;
gdjs.StartMenuCode.GDRankedModeObjects1.length = 0;
gdjs.StartMenuCode.GDRankedModeObjects2.length = 0;
gdjs.StartMenuCode.GDRankedModeObjects3.length = 0;
gdjs.StartMenuCode.GDgrassObjects1.length = 0;
gdjs.StartMenuCode.GDgrassObjects2.length = 0;
gdjs.StartMenuCode.GDgrassObjects3.length = 0;
gdjs.StartMenuCode.GDRankedTitleObjects1.length = 0;
gdjs.StartMenuCode.GDRankedTitleObjects2.length = 0;
gdjs.StartMenuCode.GDRankedTitleObjects3.length = 0;
gdjs.StartMenuCode.GDNewVideoObjects1.length = 0;
gdjs.StartMenuCode.GDNewVideoObjects2.length = 0;
gdjs.StartMenuCode.GDNewVideoObjects3.length = 0;
gdjs.StartMenuCode.GDGoldSquareToggleObjects1.length = 0;
gdjs.StartMenuCode.GDGoldSquareToggleObjects2.length = 0;
gdjs.StartMenuCode.GDGoldSquareToggleObjects3.length = 0;
gdjs.StartMenuCode.GDFelSpellObjects1.length = 0;
gdjs.StartMenuCode.GDFelSpellObjects2.length = 0;
gdjs.StartMenuCode.GDFelSpellObjects3.length = 0;
gdjs.StartMenuCode.GDLeaderboardObjects1.length = 0;
gdjs.StartMenuCode.GDLeaderboardObjects2.length = 0;
gdjs.StartMenuCode.GDLeaderboardObjects3.length = 0;
gdjs.StartMenuCode.GDGoldRoundToggleObjects1.length = 0;
gdjs.StartMenuCode.GDGoldRoundToggleObjects2.length = 0;
gdjs.StartMenuCode.GDGoldRoundToggleObjects3.length = 0;
gdjs.StartMenuCode.GDProtectionCircleObjects1.length = 0;
gdjs.StartMenuCode.GDProtectionCircleObjects2.length = 0;
gdjs.StartMenuCode.GDProtectionCircleObjects3.length = 0;
gdjs.StartMenuCode.GDheaderObjects1.length = 0;
gdjs.StartMenuCode.GDheaderObjects2.length = 0;
gdjs.StartMenuCode.GDheaderObjects3.length = 0;
gdjs.StartMenuCode.GDWallObjects1.length = 0;
gdjs.StartMenuCode.GDWallObjects2.length = 0;
gdjs.StartMenuCode.GDWallObjects3.length = 0;
gdjs.StartMenuCode.GDTreeObjects1.length = 0;
gdjs.StartMenuCode.GDTreeObjects2.length = 0;
gdjs.StartMenuCode.GDTreeObjects3.length = 0;
gdjs.StartMenuCode.GDInvetoryObjects1.length = 0;
gdjs.StartMenuCode.GDInvetoryObjects2.length = 0;
gdjs.StartMenuCode.GDInvetoryObjects3.length = 0;
gdjs.StartMenuCode.GDGameObjects1.length = 0;
gdjs.StartMenuCode.GDGameObjects2.length = 0;
gdjs.StartMenuCode.GDGameObjects3.length = 0;
gdjs.StartMenuCode.GDSettings2Objects1.length = 0;
gdjs.StartMenuCode.GDSettings2Objects2.length = 0;
gdjs.StartMenuCode.GDSettings2Objects3.length = 0;
gdjs.StartMenuCode.GDShopObjects1.length = 0;
gdjs.StartMenuCode.GDShopObjects2.length = 0;
gdjs.StartMenuCode.GDShopObjects3.length = 0;
gdjs.StartMenuCode.GDNewSprite2Objects1.length = 0;
gdjs.StartMenuCode.GDNewSprite2Objects2.length = 0;
gdjs.StartMenuCode.GDNewSprite2Objects3.length = 0;
gdjs.StartMenuCode.GDNewButtonObjects1.length = 0;
gdjs.StartMenuCode.GDNewButtonObjects2.length = 0;
gdjs.StartMenuCode.GDNewButtonObjects3.length = 0;
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects1.length = 0;
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects2.length = 0;
gdjs.StartMenuCode.GDSmallGreenPlasticRoundSwitchObjects3.length = 0;
gdjs.StartMenuCode.GDFullscreenObjects1.length = 0;
gdjs.StartMenuCode.GDFullscreenObjects2.length = 0;
gdjs.StartMenuCode.GDFullscreenObjects3.length = 0;
gdjs.StartMenuCode.GDNewButton2Objects1.length = 0;
gdjs.StartMenuCode.GDNewButton2Objects2.length = 0;
gdjs.StartMenuCode.GDNewButton2Objects3.length = 0;
gdjs.StartMenuCode.GDSquareWhiteSliderObjects1.length = 0;
gdjs.StartMenuCode.GDSquareWhiteSliderObjects2.length = 0;
gdjs.StartMenuCode.GDSquareWhiteSliderObjects3.length = 0;
gdjs.StartMenuCode.GDSoundObjects1.length = 0;
gdjs.StartMenuCode.GDSoundObjects2.length = 0;
gdjs.StartMenuCode.GDSoundObjects3.length = 0;
gdjs.StartMenuCode.GDNewButton3Objects1.length = 0;
gdjs.StartMenuCode.GDNewButton3Objects2.length = 0;
gdjs.StartMenuCode.GDNewButton3Objects3.length = 0;
gdjs.StartMenuCode.GDFranceObjects1.length = 0;
gdjs.StartMenuCode.GDFranceObjects2.length = 0;
gdjs.StartMenuCode.GDFranceObjects3.length = 0;
gdjs.StartMenuCode.GDUsaObjects1.length = 0;
gdjs.StartMenuCode.GDUsaObjects2.length = 0;
gdjs.StartMenuCode.GDUsaObjects3.length = 0;
gdjs.StartMenuCode.GDLanguageObjects1.length = 0;
gdjs.StartMenuCode.GDLanguageObjects2.length = 0;
gdjs.StartMenuCode.GDLanguageObjects3.length = 0;
gdjs.StartMenuCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.StartMenuCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.StartMenuCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.StartMenuCode.GDdiscordlinkObjects1.length = 0;
gdjs.StartMenuCode.GDdiscordlinkObjects2.length = 0;
gdjs.StartMenuCode.GDdiscordlinkObjects3.length = 0;
gdjs.StartMenuCode.GDNewTextObjects1.length = 0;
gdjs.StartMenuCode.GDNewTextObjects2.length = 0;
gdjs.StartMenuCode.GDNewTextObjects3.length = 0;
gdjs.StartMenuCode.GDcameraObjects1.length = 0;
gdjs.StartMenuCode.GDcameraObjects2.length = 0;
gdjs.StartMenuCode.GDcameraObjects3.length = 0;
gdjs.StartMenuCode.GDNewVideo2Objects1.length = 0;
gdjs.StartMenuCode.GDNewVideo2Objects2.length = 0;
gdjs.StartMenuCode.GDNewVideo2Objects3.length = 0;

gdjs.StartMenuCode.eventsList9(runtimeScene);

return;

}

gdjs['StartMenuCode'] = gdjs.StartMenuCode;
