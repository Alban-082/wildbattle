gdjs.MainGame2Code = {};
gdjs.MainGame2Code.GDBulletObjects2_1final = [];

gdjs.MainGame2Code.GDGhostOrbObjects1_1final = [];

gdjs.MainGame2Code.GDGhostOrbObjects2_1final = [];

gdjs.MainGame2Code.GDGrassBorder2Objects2_1final = [];

gdjs.MainGame2Code.GDGrassBorder3Objects2_1final = [];

gdjs.MainGame2Code.GDGrassBorder4Objects2_1final = [];

gdjs.MainGame2Code.GDGrassBorderObjects2_1final = [];

gdjs.MainGame2Code.GDPlayerObjects1_1final = [];

gdjs.MainGame2Code.GDPlayerObjects4_1final = [];

gdjs.MainGame2Code.GDRoomDoorsObjects2_1final = [];

gdjs.MainGame2Code.GDRoomFloorObjects4_1final = [];

gdjs.MainGame2Code.GDRoomObjects2_1final = [];

gdjs.MainGame2Code.GDRoomObjects4_1final = [];

gdjs.MainGame2Code.GDRoomTrapsObjects1_1final = [];

gdjs.MainGame2Code.GDRoomTrapsObjects4_1final = [];

gdjs.MainGame2Code.GDTreeObjects2_1final = [];

gdjs.MainGame2Code.GDWallObjects2_1final = [];

gdjs.MainGame2Code.forEachCount0_3 = 0;

gdjs.MainGame2Code.forEachCount0_4 = 0;

gdjs.MainGame2Code.forEachCount1_3 = 0;

gdjs.MainGame2Code.forEachCount1_4 = 0;

gdjs.MainGame2Code.forEachCount2_3 = 0;

gdjs.MainGame2Code.forEachCount2_4 = 0;

gdjs.MainGame2Code.forEachCount3_3 = 0;

gdjs.MainGame2Code.forEachCount4_3 = 0;

gdjs.MainGame2Code.forEachCount5_3 = 0;

gdjs.MainGame2Code.forEachCount6_3 = 0;

gdjs.MainGame2Code.forEachIndex2 = 0;

gdjs.MainGame2Code.forEachIndex3 = 0;

gdjs.MainGame2Code.forEachIndex4 = 0;

gdjs.MainGame2Code.forEachObjects2 = [];

gdjs.MainGame2Code.forEachObjects3 = [];

gdjs.MainGame2Code.forEachObjects4 = [];

gdjs.MainGame2Code.forEachTemporary2 = null;

gdjs.MainGame2Code.forEachTemporary3 = null;

gdjs.MainGame2Code.forEachTotalCount2 = 0;

gdjs.MainGame2Code.forEachTotalCount3 = 0;

gdjs.MainGame2Code.forEachTotalCount4 = 0;

gdjs.MainGame2Code.GDRoomTrapsObjects1= [];
gdjs.MainGame2Code.GDRoomTrapsObjects2= [];
gdjs.MainGame2Code.GDRoomTrapsObjects3= [];
gdjs.MainGame2Code.GDRoomTrapsObjects4= [];
gdjs.MainGame2Code.GDRoomTrapsObjects5= [];
gdjs.MainGame2Code.GDRoomTrapsObjects6= [];
gdjs.MainGame2Code.GDRoomDoorsObjects1= [];
gdjs.MainGame2Code.GDRoomDoorsObjects2= [];
gdjs.MainGame2Code.GDRoomDoorsObjects3= [];
gdjs.MainGame2Code.GDRoomDoorsObjects4= [];
gdjs.MainGame2Code.GDRoomDoorsObjects5= [];
gdjs.MainGame2Code.GDRoomDoorsObjects6= [];
gdjs.MainGame2Code.GDRoomFloorObjects1= [];
gdjs.MainGame2Code.GDRoomFloorObjects2= [];
gdjs.MainGame2Code.GDRoomFloorObjects3= [];
gdjs.MainGame2Code.GDRoomFloorObjects4= [];
gdjs.MainGame2Code.GDRoomFloorObjects5= [];
gdjs.MainGame2Code.GDRoomFloorObjects6= [];
gdjs.MainGame2Code.GDRoomObjects1= [];
gdjs.MainGame2Code.GDRoomObjects2= [];
gdjs.MainGame2Code.GDRoomObjects3= [];
gdjs.MainGame2Code.GDRoomObjects4= [];
gdjs.MainGame2Code.GDRoomObjects5= [];
gdjs.MainGame2Code.GDRoomObjects6= [];
gdjs.MainGame2Code.GDPlayerObjects1= [];
gdjs.MainGame2Code.GDPlayerObjects2= [];
gdjs.MainGame2Code.GDPlayerObjects3= [];
gdjs.MainGame2Code.GDPlayerObjects4= [];
gdjs.MainGame2Code.GDPlayerObjects5= [];
gdjs.MainGame2Code.GDPlayerObjects6= [];
gdjs.MainGame2Code.GDGunObjects1= [];
gdjs.MainGame2Code.GDGunObjects2= [];
gdjs.MainGame2Code.GDGunObjects3= [];
gdjs.MainGame2Code.GDGunObjects4= [];
gdjs.MainGame2Code.GDGunObjects5= [];
gdjs.MainGame2Code.GDGunObjects6= [];
gdjs.MainGame2Code.GDImpObjects1= [];
gdjs.MainGame2Code.GDImpObjects2= [];
gdjs.MainGame2Code.GDImpObjects3= [];
gdjs.MainGame2Code.GDImpObjects4= [];
gdjs.MainGame2Code.GDImpObjects5= [];
gdjs.MainGame2Code.GDImpObjects6= [];
gdjs.MainGame2Code.GDSpiderObjects1= [];
gdjs.MainGame2Code.GDSpiderObjects2= [];
gdjs.MainGame2Code.GDSpiderObjects3= [];
gdjs.MainGame2Code.GDSpiderObjects4= [];
gdjs.MainGame2Code.GDSpiderObjects5= [];
gdjs.MainGame2Code.GDSpiderObjects6= [];
gdjs.MainGame2Code.GDGhostObjects1= [];
gdjs.MainGame2Code.GDGhostObjects2= [];
gdjs.MainGame2Code.GDGhostObjects3= [];
gdjs.MainGame2Code.GDGhostObjects4= [];
gdjs.MainGame2Code.GDGhostObjects5= [];
gdjs.MainGame2Code.GDGhostObjects6= [];
gdjs.MainGame2Code.GDGhostOrbObjects1= [];
gdjs.MainGame2Code.GDGhostOrbObjects2= [];
gdjs.MainGame2Code.GDGhostOrbObjects3= [];
gdjs.MainGame2Code.GDGhostOrbObjects4= [];
gdjs.MainGame2Code.GDGhostOrbObjects5= [];
gdjs.MainGame2Code.GDGhostOrbObjects6= [];
gdjs.MainGame2Code.GDBulletObjects1= [];
gdjs.MainGame2Code.GDBulletObjects2= [];
gdjs.MainGame2Code.GDBulletObjects3= [];
gdjs.MainGame2Code.GDBulletObjects4= [];
gdjs.MainGame2Code.GDBulletObjects5= [];
gdjs.MainGame2Code.GDBulletObjects6= [];
gdjs.MainGame2Code.GDUpgradeTextObjects1= [];
gdjs.MainGame2Code.GDUpgradeTextObjects2= [];
gdjs.MainGame2Code.GDUpgradeTextObjects3= [];
gdjs.MainGame2Code.GDUpgradeTextObjects4= [];
gdjs.MainGame2Code.GDUpgradeTextObjects5= [];
gdjs.MainGame2Code.GDUpgradeTextObjects6= [];
gdjs.MainGame2Code.GDEnemyDamageTextObjects1= [];
gdjs.MainGame2Code.GDEnemyDamageTextObjects2= [];
gdjs.MainGame2Code.GDEnemyDamageTextObjects3= [];
gdjs.MainGame2Code.GDEnemyDamageTextObjects4= [];
gdjs.MainGame2Code.GDEnemyDamageTextObjects5= [];
gdjs.MainGame2Code.GDEnemyDamageTextObjects6= [];
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects1= [];
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects2= [];
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects3= [];
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects4= [];
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects5= [];
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects6= [];
gdjs.MainGame2Code.GDParticle_9595DashObjects1= [];
gdjs.MainGame2Code.GDParticle_9595DashObjects2= [];
gdjs.MainGame2Code.GDParticle_9595DashObjects3= [];
gdjs.MainGame2Code.GDParticle_9595DashObjects4= [];
gdjs.MainGame2Code.GDParticle_9595DashObjects5= [];
gdjs.MainGame2Code.GDParticle_9595DashObjects6= [];
gdjs.MainGame2Code.GDParticle_9595DeathObjects1= [];
gdjs.MainGame2Code.GDParticle_9595DeathObjects2= [];
gdjs.MainGame2Code.GDParticle_9595DeathObjects3= [];
gdjs.MainGame2Code.GDParticle_9595DeathObjects4= [];
gdjs.MainGame2Code.GDParticle_9595DeathObjects5= [];
gdjs.MainGame2Code.GDParticle_9595DeathObjects6= [];
gdjs.MainGame2Code.GDHealthBarObjects1= [];
gdjs.MainGame2Code.GDHealthBarObjects2= [];
gdjs.MainGame2Code.GDHealthBarObjects3= [];
gdjs.MainGame2Code.GDHealthBarObjects4= [];
gdjs.MainGame2Code.GDHealthBarObjects5= [];
gdjs.MainGame2Code.GDHealthBarObjects6= [];
gdjs.MainGame2Code.GDDebugObjects1= [];
gdjs.MainGame2Code.GDDebugObjects2= [];
gdjs.MainGame2Code.GDDebugObjects3= [];
gdjs.MainGame2Code.GDDebugObjects4= [];
gdjs.MainGame2Code.GDDebugObjects5= [];
gdjs.MainGame2Code.GDDebugObjects6= [];
gdjs.MainGame2Code.GDUpgradeIconsObjects1= [];
gdjs.MainGame2Code.GDUpgradeIconsObjects2= [];
gdjs.MainGame2Code.GDUpgradeIconsObjects3= [];
gdjs.MainGame2Code.GDUpgradeIconsObjects4= [];
gdjs.MainGame2Code.GDUpgradeIconsObjects5= [];
gdjs.MainGame2Code.GDUpgradeIconsObjects6= [];
gdjs.MainGame2Code.GDUpgradesObjects1= [];
gdjs.MainGame2Code.GDUpgradesObjects2= [];
gdjs.MainGame2Code.GDUpgradesObjects3= [];
gdjs.MainGame2Code.GDUpgradesObjects4= [];
gdjs.MainGame2Code.GDUpgradesObjects5= [];
gdjs.MainGame2Code.GDUpgradesObjects6= [];
gdjs.MainGame2Code.GDTotalPointsCountObjects1= [];
gdjs.MainGame2Code.GDTotalPointsCountObjects2= [];
gdjs.MainGame2Code.GDTotalPointsCountObjects3= [];
gdjs.MainGame2Code.GDTotalPointsCountObjects4= [];
gdjs.MainGame2Code.GDTotalPointsCountObjects5= [];
gdjs.MainGame2Code.GDTotalPointsCountObjects6= [];
gdjs.MainGame2Code.GDTotalPointsObjects1= [];
gdjs.MainGame2Code.GDTotalPointsObjects2= [];
gdjs.MainGame2Code.GDTotalPointsObjects3= [];
gdjs.MainGame2Code.GDTotalPointsObjects4= [];
gdjs.MainGame2Code.GDTotalPointsObjects5= [];
gdjs.MainGame2Code.GDTotalPointsObjects6= [];
gdjs.MainGame2Code.GDDangerLevelCountObjects1= [];
gdjs.MainGame2Code.GDDangerLevelCountObjects2= [];
gdjs.MainGame2Code.GDDangerLevelCountObjects3= [];
gdjs.MainGame2Code.GDDangerLevelCountObjects4= [];
gdjs.MainGame2Code.GDDangerLevelCountObjects5= [];
gdjs.MainGame2Code.GDDangerLevelCountObjects6= [];
gdjs.MainGame2Code.GDDangerLevelObjects1= [];
gdjs.MainGame2Code.GDDangerLevelObjects2= [];
gdjs.MainGame2Code.GDDangerLevelObjects3= [];
gdjs.MainGame2Code.GDDangerLevelObjects4= [];
gdjs.MainGame2Code.GDDangerLevelObjects5= [];
gdjs.MainGame2Code.GDDangerLevelObjects6= [];
gdjs.MainGame2Code.GDPick_9595UpsObjects1= [];
gdjs.MainGame2Code.GDPick_9595UpsObjects2= [];
gdjs.MainGame2Code.GDPick_9595UpsObjects3= [];
gdjs.MainGame2Code.GDPick_9595UpsObjects4= [];
gdjs.MainGame2Code.GDPick_9595UpsObjects5= [];
gdjs.MainGame2Code.GDPick_9595UpsObjects6= [];
gdjs.MainGame2Code.GDReset_9595TimerObjects1= [];
gdjs.MainGame2Code.GDReset_9595TimerObjects2= [];
gdjs.MainGame2Code.GDReset_9595TimerObjects3= [];
gdjs.MainGame2Code.GDReset_9595TimerObjects4= [];
gdjs.MainGame2Code.GDReset_9595TimerObjects5= [];
gdjs.MainGame2Code.GDReset_9595TimerObjects6= [];
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects1= [];
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2= [];
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects3= [];
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects4= [];
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects5= [];
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects6= [];
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects1= [];
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2= [];
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3= [];
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects4= [];
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects5= [];
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects6= [];
gdjs.MainGame2Code.GDReset_9595ButtonObjects1= [];
gdjs.MainGame2Code.GDReset_9595ButtonObjects2= [];
gdjs.MainGame2Code.GDReset_9595ButtonObjects3= [];
gdjs.MainGame2Code.GDReset_9595ButtonObjects4= [];
gdjs.MainGame2Code.GDReset_9595ButtonObjects5= [];
gdjs.MainGame2Code.GDReset_9595ButtonObjects6= [];
gdjs.MainGame2Code.GDDarkeningObjects1= [];
gdjs.MainGame2Code.GDDarkeningObjects2= [];
gdjs.MainGame2Code.GDDarkeningObjects3= [];
gdjs.MainGame2Code.GDDarkeningObjects4= [];
gdjs.MainGame2Code.GDDarkeningObjects5= [];
gdjs.MainGame2Code.GDDarkeningObjects6= [];
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects1= [];
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2= [];
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects3= [];
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects4= [];
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects5= [];
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects6= [];
gdjs.MainGame2Code.GDPause_9595TextObjects1= [];
gdjs.MainGame2Code.GDPause_9595TextObjects2= [];
gdjs.MainGame2Code.GDPause_9595TextObjects3= [];
gdjs.MainGame2Code.GDPause_9595TextObjects4= [];
gdjs.MainGame2Code.GDPause_9595TextObjects5= [];
gdjs.MainGame2Code.GDPause_9595TextObjects6= [];
gdjs.MainGame2Code.GDUpgrade_9595TextObjects1= [];
gdjs.MainGame2Code.GDUpgrade_9595TextObjects2= [];
gdjs.MainGame2Code.GDUpgrade_9595TextObjects3= [];
gdjs.MainGame2Code.GDUpgrade_9595TextObjects4= [];
gdjs.MainGame2Code.GDUpgrade_9595TextObjects5= [];
gdjs.MainGame2Code.GDUpgrade_9595TextObjects6= [];
gdjs.MainGame2Code.GDHelpIconObjects1= [];
gdjs.MainGame2Code.GDHelpIconObjects2= [];
gdjs.MainGame2Code.GDHelpIconObjects3= [];
gdjs.MainGame2Code.GDHelpIconObjects4= [];
gdjs.MainGame2Code.GDHelpIconObjects5= [];
gdjs.MainGame2Code.GDHelpIconObjects6= [];
gdjs.MainGame2Code.GDMobileCoveringObjects1= [];
gdjs.MainGame2Code.GDMobileCoveringObjects2= [];
gdjs.MainGame2Code.GDMobileCoveringObjects3= [];
gdjs.MainGame2Code.GDMobileCoveringObjects4= [];
gdjs.MainGame2Code.GDMobileCoveringObjects5= [];
gdjs.MainGame2Code.GDMobileCoveringObjects6= [];
gdjs.MainGame2Code.GDMovementJoystickObjects1= [];
gdjs.MainGame2Code.GDMovementJoystickObjects2= [];
gdjs.MainGame2Code.GDMovementJoystickObjects3= [];
gdjs.MainGame2Code.GDMovementJoystickObjects4= [];
gdjs.MainGame2Code.GDMovementJoystickObjects5= [];
gdjs.MainGame2Code.GDMovementJoystickObjects6= [];
gdjs.MainGame2Code.GDAimingJoystickObjects1= [];
gdjs.MainGame2Code.GDAimingJoystickObjects2= [];
gdjs.MainGame2Code.GDAimingJoystickObjects3= [];
gdjs.MainGame2Code.GDAimingJoystickObjects4= [];
gdjs.MainGame2Code.GDAimingJoystickObjects5= [];
gdjs.MainGame2Code.GDAimingJoystickObjects6= [];
gdjs.MainGame2Code.GDNewTiledSpriteObjects1= [];
gdjs.MainGame2Code.GDNewTiledSpriteObjects2= [];
gdjs.MainGame2Code.GDNewTiledSpriteObjects3= [];
gdjs.MainGame2Code.GDNewTiledSpriteObjects4= [];
gdjs.MainGame2Code.GDNewTiledSpriteObjects5= [];
gdjs.MainGame2Code.GDNewTiledSpriteObjects6= [];
gdjs.MainGame2Code.GDGrassBorderObjects1= [];
gdjs.MainGame2Code.GDGrassBorderObjects2= [];
gdjs.MainGame2Code.GDGrassBorderObjects3= [];
gdjs.MainGame2Code.GDGrassBorderObjects4= [];
gdjs.MainGame2Code.GDGrassBorderObjects5= [];
gdjs.MainGame2Code.GDGrassBorderObjects6= [];
gdjs.MainGame2Code.GDGrassBorder2Objects1= [];
gdjs.MainGame2Code.GDGrassBorder2Objects2= [];
gdjs.MainGame2Code.GDGrassBorder2Objects3= [];
gdjs.MainGame2Code.GDGrassBorder2Objects4= [];
gdjs.MainGame2Code.GDGrassBorder2Objects5= [];
gdjs.MainGame2Code.GDGrassBorder2Objects6= [];
gdjs.MainGame2Code.GDGrassBorder4Objects1= [];
gdjs.MainGame2Code.GDGrassBorder4Objects2= [];
gdjs.MainGame2Code.GDGrassBorder4Objects3= [];
gdjs.MainGame2Code.GDGrassBorder4Objects4= [];
gdjs.MainGame2Code.GDGrassBorder4Objects5= [];
gdjs.MainGame2Code.GDGrassBorder4Objects6= [];
gdjs.MainGame2Code.GDGrassBorder3Objects1= [];
gdjs.MainGame2Code.GDGrassBorder3Objects2= [];
gdjs.MainGame2Code.GDGrassBorder3Objects3= [];
gdjs.MainGame2Code.GDGrassBorder3Objects4= [];
gdjs.MainGame2Code.GDGrassBorder3Objects5= [];
gdjs.MainGame2Code.GDGrassBorder3Objects6= [];
gdjs.MainGame2Code.GDTreeObjects1= [];
gdjs.MainGame2Code.GDTreeObjects2= [];
gdjs.MainGame2Code.GDTreeObjects3= [];
gdjs.MainGame2Code.GDTreeObjects4= [];
gdjs.MainGame2Code.GDTreeObjects5= [];
gdjs.MainGame2Code.GDTreeObjects6= [];
gdjs.MainGame2Code.GDWallObjects1= [];
gdjs.MainGame2Code.GDWallObjects2= [];
gdjs.MainGame2Code.GDWallObjects3= [];
gdjs.MainGame2Code.GDWallObjects4= [];
gdjs.MainGame2Code.GDWallObjects5= [];
gdjs.MainGame2Code.GDWallObjects6= [];
gdjs.MainGame2Code.GDNewTextObjects1= [];
gdjs.MainGame2Code.GDNewTextObjects2= [];
gdjs.MainGame2Code.GDNewTextObjects3= [];
gdjs.MainGame2Code.GDNewTextObjects4= [];
gdjs.MainGame2Code.GDNewTextObjects5= [];
gdjs.MainGame2Code.GDNewTextObjects6= [];
gdjs.MainGame2Code.GDscoreObjects1= [];
gdjs.MainGame2Code.GDscoreObjects2= [];
gdjs.MainGame2Code.GDscoreObjects3= [];
gdjs.MainGame2Code.GDscoreObjects4= [];
gdjs.MainGame2Code.GDscoreObjects5= [];
gdjs.MainGame2Code.GDscoreObjects6= [];
gdjs.MainGame2Code.GDpointsObjects1= [];
gdjs.MainGame2Code.GDpointsObjects2= [];
gdjs.MainGame2Code.GDpointsObjects3= [];
gdjs.MainGame2Code.GDpointsObjects4= [];
gdjs.MainGame2Code.GDpointsObjects5= [];
gdjs.MainGame2Code.GDpointsObjects6= [];
gdjs.MainGame2Code.GDNewPanelSpriteObjects1= [];
gdjs.MainGame2Code.GDNewPanelSpriteObjects2= [];
gdjs.MainGame2Code.GDNewPanelSpriteObjects3= [];
gdjs.MainGame2Code.GDNewPanelSpriteObjects4= [];
gdjs.MainGame2Code.GDNewPanelSpriteObjects5= [];
gdjs.MainGame2Code.GDNewPanelSpriteObjects6= [];
gdjs.MainGame2Code.GDSpawnPointObjects1= [];
gdjs.MainGame2Code.GDSpawnPointObjects2= [];
gdjs.MainGame2Code.GDSpawnPointObjects3= [];
gdjs.MainGame2Code.GDSpawnPointObjects4= [];
gdjs.MainGame2Code.GDSpawnPointObjects5= [];
gdjs.MainGame2Code.GDSpawnPointObjects6= [];
gdjs.MainGame2Code.GDRankObjects1= [];
gdjs.MainGame2Code.GDRankObjects2= [];
gdjs.MainGame2Code.GDRankObjects3= [];
gdjs.MainGame2Code.GDRankObjects4= [];
gdjs.MainGame2Code.GDRankObjects5= [];
gdjs.MainGame2Code.GDRankObjects6= [];
gdjs.MainGame2Code.GDcrossairObjects1= [];
gdjs.MainGame2Code.GDcrossairObjects2= [];
gdjs.MainGame2Code.GDcrossairObjects3= [];
gdjs.MainGame2Code.GDcrossairObjects4= [];
gdjs.MainGame2Code.GDcrossairObjects5= [];
gdjs.MainGame2Code.GDcrossairObjects6= [];
gdjs.MainGame2Code.GDTree2Objects1= [];
gdjs.MainGame2Code.GDTree2Objects2= [];
gdjs.MainGame2Code.GDTree2Objects3= [];
gdjs.MainGame2Code.GDTree2Objects4= [];
gdjs.MainGame2Code.GDTree2Objects5= [];
gdjs.MainGame2Code.GDTree2Objects6= [];
gdjs.MainGame2Code.GDgrass2Objects1= [];
gdjs.MainGame2Code.GDgrass2Objects2= [];
gdjs.MainGame2Code.GDgrass2Objects3= [];
gdjs.MainGame2Code.GDgrass2Objects4= [];
gdjs.MainGame2Code.GDgrass2Objects5= [];
gdjs.MainGame2Code.GDgrass2Objects6= [];
gdjs.MainGame2Code.GDgrass1Objects1= [];
gdjs.MainGame2Code.GDgrass1Objects2= [];
gdjs.MainGame2Code.GDgrass1Objects3= [];
gdjs.MainGame2Code.GDgrass1Objects4= [];
gdjs.MainGame2Code.GDgrass1Objects5= [];
gdjs.MainGame2Code.GDgrass1Objects6= [];
gdjs.MainGame2Code.GDGroundObjects1= [];
gdjs.MainGame2Code.GDGroundObjects2= [];
gdjs.MainGame2Code.GDGroundObjects3= [];
gdjs.MainGame2Code.GDGroundObjects4= [];
gdjs.MainGame2Code.GDGroundObjects5= [];
gdjs.MainGame2Code.GDGroundObjects6= [];
gdjs.MainGame2Code.GDGoldenImpObjects1= [];
gdjs.MainGame2Code.GDGoldenImpObjects2= [];
gdjs.MainGame2Code.GDGoldenImpObjects3= [];
gdjs.MainGame2Code.GDGoldenImpObjects4= [];
gdjs.MainGame2Code.GDGoldenImpObjects5= [];
gdjs.MainGame2Code.GDGoldenImpObjects6= [];


gdjs.MainGame2Code.eventsList0 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList1 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGame2Code.GDUpgradesObjects2);

for (gdjs.MainGame2Code.forEachIndex3 = 0;gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.GDUpgradesObjects2.length;++gdjs.MainGame2Code.forEachIndex3) {
gdjs.MainGame2Code.GDUpgradesObjects3.length = 0;


gdjs.MainGame2Code.forEachTemporary3 = gdjs.MainGame2Code.GDUpgradesObjects2[gdjs.MainGame2Code.forEachIndex3];
gdjs.MainGame2Code.GDUpgradesObjects3.push(gdjs.MainGame2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects3[i].setAnimation(gdjs.randomInRange(0, 4));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 0, 5, 0, 2, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects3[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects3[i].setZOrder((gdjs.MainGame2Code.GDUpgradesObjects3[i].getPointY("")));
}
}}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradesObjects1Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGame2Code.GDUpgradesObjects1});
gdjs.MainGame2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGame2Code.GDHealthBarObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "PickUp.wav", false, 30, 1);
}{for(var i = 0, len = gdjs.MainGame2Code.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDHealthBarObjects2[i].SetMaxValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Health")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGame2Code.GDUpgradesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradesObjects1Objects) == 2;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDUpgradesObjects1 */
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects2Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGame2Code.GDRoomFloorObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.eventsList3 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimeScale(runtimeScene) == 0.05;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointX("")), (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointY(""))) < 5);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)).setNumber(0);
}
}}

}


};gdjs.MainGame2Code.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects2[k] = gdjs.MainGame2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].addForce(0, -(500), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects2[k] = gdjs.MainGame2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].addForce(0, 500, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects2[k] = gdjs.MainGame2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].addForce(-(400), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects1[i].getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects1[i].getVariables().getFromIndex(4)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects1[k] = gdjs.MainGame2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].addForce(400, 0, 0);
}
}}

}


};gdjs.MainGame2Code.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "MobileCovering", 0);
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "24;20;37");
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointY("")), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointX("")), "", 0);
}{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "MobileCovering", 0);
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "24;20;37");
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointY("")), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointX("")), "", 0);
}{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MobileCovering"), gdjs.MainGame2Code.GDMobileCoveringObjects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainGame2Code.GDMobileCoveringObjects2.length !== 0 ? gdjs.MainGame2Code.GDMobileCoveringObjects2[0] : null), true, "MobileCovering", 0);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects2Objects, (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointY("")), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects) == 1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointX("")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointY("")), 0.05), "", 0);
}
{ //Subevents
gdjs.MainGame2Code.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainGame2Code.GDRoomFloorObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects1[0].getPointX("")), (( gdjs.MainGame2Code.GDRoomFloorObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects1[0].getPointY(""))) >= 5);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects2Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGame2Code.GDRoomFloorObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects3Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects3Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGame2Code.GDRoomFloorObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects3Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGame2Code.GDRoomTrapsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects3Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGame2Code.GDRoomDoorsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects4Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGame2Code.GDRoomFloorObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradesObjects4Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGame2Code.GDUpgradesObjects4});
gdjs.MainGame2Code.eventsList6 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects4Objects, (( gdjs.MainGame2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects4[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects4[0].getPointY("")), false);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects3, gdjs.MainGame2Code.GDRoomObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomDoorsObjects3, gdjs.MainGame2Code.GDRoomDoorsObjects4);

/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects4 */
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomObjects4[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("NewRoomAnimation")));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDRoomDoorsObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomDoorsObjects4[i].setAnimation((( gdjs.MainGame2Code.GDRoomObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects4[0].getAnimation()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDRoomFloorObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomFloorObjects4[i].setAnimation((( gdjs.MainGame2Code.GDRoomObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects4[0].getAnimation()));
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects3, gdjs.MainGame2Code.GDRoomTrapsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomTrapsObjects4.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomTrapsObjects4[i].getAnimation() >= 3 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDRoomTrapsObjects4[k] = gdjs.MainGame2Code.GDRoomTrapsObjects4[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomTrapsObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomTrapsObjects4.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomTrapsObjects4[i].getAnimation() <= 4 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDRoomTrapsObjects4[k] = gdjs.MainGame2Code.GDRoomTrapsObjects4[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomTrapsObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDRoomTrapsObjects4 */
gdjs.MainGame2Code.GDUpgradesObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradesObjects4Objects, (( gdjs.MainGame2Code.GDRoomTrapsObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomTrapsObjects4[0].getPointX("")), (( gdjs.MainGame2Code.GDRoomTrapsObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomTrapsObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects4[i].setAnimation(gdjs.randomInRange(0, 4));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 0, 5, 0, 2, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects4[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects4[i].setZOrder((gdjs.MainGame2Code.GDUpgradesObjects4[i].getPointY("")));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects3Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGame2Code.GDRoomFloorObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects3Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGame2Code.GDRoomFloorObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects4});
gdjs.MainGame2Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

gdjs.MainGame2Code.GDGhostObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

gdjs.MainGame2Code.GDGhostObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);

gdjs.MainGame2Code.GDGhostObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects5Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects5Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects5});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects4});
gdjs.MainGame2Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 3;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

gdjs.MainGame2Code.GDGhostObjects5.length = 0;

gdjs.MainGame2Code.GDSpiderObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 4;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

gdjs.MainGame2Code.GDGhostObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 5;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

gdjs.MainGame2Code.GDSpiderObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 6;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);

gdjs.MainGame2Code.GDSpiderObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects4});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects4});
gdjs.MainGame2Code.eventsList9 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList10 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) < 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) < 7;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 7;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);

gdjs.MainGame2Code.GDGhostObjects4.length = 0;

gdjs.MainGame2Code.GDImpObjects4.length = 0;

gdjs.MainGame2Code.GDSpiderObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 8;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);

gdjs.MainGame2Code.GDGhostObjects4.length = 0;

gdjs.MainGame2Code.GDSpiderObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 9;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);

gdjs.MainGame2Code.GDImpObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 10;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);

gdjs.MainGame2Code.GDImpObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGame2Code.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

gdjs.MainGame2Code.forEachTotalCount4 = 0;
gdjs.MainGame2Code.forEachObjects4.length = 0;
gdjs.MainGame2Code.forEachCount0_4 = gdjs.MainGame2Code.GDGhostObjects3.length;
gdjs.MainGame2Code.forEachTotalCount4 += gdjs.MainGame2Code.forEachCount0_4;
gdjs.MainGame2Code.forEachObjects4.push.apply(gdjs.MainGame2Code.forEachObjects4,gdjs.MainGame2Code.GDGhostObjects3);
gdjs.MainGame2Code.forEachCount1_4 = gdjs.MainGame2Code.GDSpiderObjects3.length;
gdjs.MainGame2Code.forEachTotalCount4 += gdjs.MainGame2Code.forEachCount1_4;
gdjs.MainGame2Code.forEachObjects4.push.apply(gdjs.MainGame2Code.forEachObjects4,gdjs.MainGame2Code.GDSpiderObjects3);
gdjs.MainGame2Code.forEachCount2_4 = gdjs.MainGame2Code.GDImpObjects3.length;
gdjs.MainGame2Code.forEachTotalCount4 += gdjs.MainGame2Code.forEachCount2_4;
gdjs.MainGame2Code.forEachObjects4.push.apply(gdjs.MainGame2Code.forEachObjects4,gdjs.MainGame2Code.GDImpObjects3);
for (gdjs.MainGame2Code.forEachIndex4 = 0;gdjs.MainGame2Code.forEachIndex4 < gdjs.MainGame2Code.forEachTotalCount4;++gdjs.MainGame2Code.forEachIndex4) {
gdjs.MainGame2Code.GDGhostObjects4.length = 0;

gdjs.MainGame2Code.GDImpObjects4.length = 0;

gdjs.MainGame2Code.GDSpiderObjects4.length = 0;


if (gdjs.MainGame2Code.forEachIndex4 < gdjs.MainGame2Code.forEachCount0_4) {
    gdjs.MainGame2Code.GDGhostObjects4.push(gdjs.MainGame2Code.forEachObjects4[gdjs.MainGame2Code.forEachIndex4]);
}
else if (gdjs.MainGame2Code.forEachIndex4 < gdjs.MainGame2Code.forEachCount0_4+gdjs.MainGame2Code.forEachCount1_4) {
    gdjs.MainGame2Code.GDSpiderObjects4.push(gdjs.MainGame2Code.forEachObjects4[gdjs.MainGame2Code.forEachIndex4]);
}
else if (gdjs.MainGame2Code.forEachIndex4 < gdjs.MainGame2Code.forEachCount0_4+gdjs.MainGame2Code.forEachCount1_4+gdjs.MainGame2Code.forEachCount2_4) {
    gdjs.MainGame2Code.GDImpObjects4.push(gdjs.MainGame2Code.forEachObjects4[gdjs.MainGame2Code.forEachIndex4]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects4[i].getBehavior("Health").SetHealth((gdjs.MainGame2Code.GDGhostObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("DangerLevelRounded")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects4[i].getBehavior("Health").SetHealth((gdjs.MainGame2Code.GDSpiderObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("DangerLevelRounded")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects4[i].getBehavior("Health").SetHealth((gdjs.MainGame2Code.GDImpObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("DangerLevelRounded")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects2, gdjs.MainGame2Code.GDRoomFloorObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects3[i].getY() <= (( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getPointY("")) - 50 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects3[k] = gdjs.MainGame2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects3 */
{runtimeScene.getScene().getVariables().get("NewRoomDeltaX").setNumber(0);
}{runtimeScene.getScene().getVariables().get("NewRoomDeltaY").setNumber(-((( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getHeight())));
}{runtimeScene.getScene().getVariables().get("NewRoomAnimation").setNumber(gdjs.random(1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(4)).setNumber(1);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects2, gdjs.MainGame2Code.GDRoomFloorObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects3[i].getY() >= (( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getPointY("")) + 50 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects3[k] = gdjs.MainGame2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects3 */
{runtimeScene.getScene().getVariables().get("NewRoomDeltaX").setNumber(0);
}{runtimeScene.getScene().getVariables().get("NewRoomDeltaY").setNumber((( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getHeight()));
}{runtimeScene.getScene().getVariables().get("NewRoomAnimation").setNumber(gdjs.randomWithStep(0, 2, 2));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(4)).setNumber(2);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects2, gdjs.MainGame2Code.GDRoomFloorObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects3[i].getX() <= (( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getPointX("")) - 50 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects3[k] = gdjs.MainGame2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects3 */
{runtimeScene.getScene().getVariables().get("NewRoomDeltaX").setNumber(-((( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getWidth())));
}{runtimeScene.getScene().getVariables().get("NewRoomDeltaY").setNumber(0);
}{runtimeScene.getScene().getVariables().get("NewRoomAnimation").setNumber(gdjs.randomWithStep(0, 3, 3));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(4)).setNumber(3);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects2, gdjs.MainGame2Code.GDRoomFloorObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects3[i].getX() >= (( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getPointX("")) + 50 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects3[k] = gdjs.MainGame2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects3 */
{runtimeScene.getScene().getVariables().get("NewRoomDeltaX").setNumber((( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getWidth()));
}{runtimeScene.getScene().getVariables().get("NewRoomDeltaY").setNumber(0);
}{runtimeScene.getScene().getVariables().get("NewRoomAnimation").setNumber(gdjs.randomWithStep(0, 3, 3));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(4)).setNumber(4);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects2, gdjs.MainGame2Code.GDRoomFloorObjects3);

gdjs.MainGame2Code.GDRoomObjects3.length = 0;

gdjs.MainGame2Code.GDRoomDoorsObjects3.length = 0;

gdjs.MainGame2Code.GDRoomTrapsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects3Objects, (( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("NewRoomDeltaX")), (( gdjs.MainGame2Code.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects3[0].getPointY("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("NewRoomDeltaY")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects3Objects, (( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects3Objects, (( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects3Objects, (( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDRoomObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomObjects3[i].setZOrder((gdjs.MainGame2Code.GDRoomObjects3[i].getPointY("")) - 100);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDRoomDoorsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomDoorsObjects3[i].setZOrder((( gdjs.MainGame2Code.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomObjects3[0].getPointY("")) - 99);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDRoomTrapsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomTrapsObjects3[i].setAnimation(gdjs.randomInRange(0, 4));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects2, gdjs.MainGame2Code.GDRoomFloorObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects3Objects, (( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointY("")), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects) == 1;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects) == 1;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.05);
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects1});
gdjs.MainGame2Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects3, gdjs.MainGame2Code.GDRoomTrapsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.MainGame2Code.GDPlayerObjects4_1final.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects3, gdjs.MainGame2Code.GDRoomTrapsObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomTrapsObjects5[i].getX() > (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")) + 260 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomTrapsObjects5[k] = gdjs.MainGame2Code.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomTrapsObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomTrapsObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.push(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects3, gdjs.MainGame2Code.GDRoomTrapsObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomTrapsObjects5[i].getX() < (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")) - 260 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomTrapsObjects5[k] = gdjs.MainGame2Code.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomTrapsObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomTrapsObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.push(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects3, gdjs.MainGame2Code.GDRoomTrapsObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomTrapsObjects5[i].getY() < (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) - 167 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomTrapsObjects5[k] = gdjs.MainGame2Code.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomTrapsObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomTrapsObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.push(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects3, gdjs.MainGame2Code.GDRoomTrapsObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomTrapsObjects5[i].getY() > (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) + 167 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomTrapsObjects5[k] = gdjs.MainGame2Code.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomTrapsObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomTrapsObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomTrapsObjects4_1final.push(gdjs.MainGame2Code.GDRoomTrapsObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects4_1final, gdjs.MainGame2Code.GDPlayerObjects4);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects4_1final, gdjs.MainGame2Code.GDRoomTrapsObjects4);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDRoomTrapsObjects4 */
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomTrapsObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomTrapsObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects3, gdjs.MainGame2Code.GDRoomObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.MainGame2Code.GDPlayerObjects4_1final.length = 0;
gdjs.MainGame2Code.GDRoomObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects3, gdjs.MainGame2Code.GDRoomObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomObjects5[i].getX() > (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")) + 260 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomObjects5[k] = gdjs.MainGame2Code.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomObjects4_1final.push(gdjs.MainGame2Code.GDRoomObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects3, gdjs.MainGame2Code.GDRoomObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomObjects5[i].getX() < (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")) - 260 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomObjects5[k] = gdjs.MainGame2Code.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomObjects4_1final.push(gdjs.MainGame2Code.GDRoomObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects3, gdjs.MainGame2Code.GDRoomObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomObjects5[i].getY() < (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) - 167 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomObjects5[k] = gdjs.MainGame2Code.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomObjects4_1final.push(gdjs.MainGame2Code.GDRoomObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects3, gdjs.MainGame2Code.GDRoomObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomObjects5[i].getY() > (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) + 167 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomObjects5[k] = gdjs.MainGame2Code.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomObjects4_1final.push(gdjs.MainGame2Code.GDRoomObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects4_1final, gdjs.MainGame2Code.GDPlayerObjects4);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects4_1final, gdjs.MainGame2Code.GDRoomObjects4);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDRoomObjects4 */
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.MainGame2Code.GDPlayerObjects4_1final.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomFloorObjects5[i].getX() > (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")) + 260 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomFloorObjects5[k] = gdjs.MainGame2Code.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomFloorObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomFloorObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomFloorObjects4_1final.push(gdjs.MainGame2Code.GDRoomFloorObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomFloorObjects5[i].getX() < (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")) - 260 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomFloorObjects5[k] = gdjs.MainGame2Code.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomFloorObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomFloorObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomFloorObjects4_1final.push(gdjs.MainGame2Code.GDRoomFloorObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomFloorObjects5[i].getY() < (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) - 167 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomFloorObjects5[k] = gdjs.MainGame2Code.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomFloorObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomFloorObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomFloorObjects4_1final.push(gdjs.MainGame2Code.GDRoomFloorObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects5);

gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects3, gdjs.MainGame2Code.GDRoomFloorObjects5);

for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomFloorObjects5[i].getY() > (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) + 167 ) {
        isConditionTrue_1 = true;
        gdjs.MainGame2Code.GDRoomFloorObjects5[k] = gdjs.MainGame2Code.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomFloorObjects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects4_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects4_1final.push(gdjs.MainGame2Code.GDPlayerObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomFloorObjects5.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGame2Code.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGame2Code.GDRoomFloorObjects4_1final.push(gdjs.MainGame2Code.GDRoomFloorObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects4_1final, gdjs.MainGame2Code.GDPlayerObjects4);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomFloorObjects4_1final, gdjs.MainGame2Code.GDRoomFloorObjects4);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDRoomFloorObjects4 */
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomFloorObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomFloorObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects1ObjectsGDgdjs_9546MainGame2Code_9546GDSpiderObjects1ObjectsGDgdjs_9546MainGame2Code_9546GDImpObjects1Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects1, "Spider": gdjs.MainGame2Code.GDSpiderObjects1, "Imp": gdjs.MainGame2Code.GDImpObjects1});
gdjs.MainGame2Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGame2Code.GDRoomDoorsObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomDoorsObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomDoorsObjects2[i].setOpacity(gdjs.MainGame2Code.GDRoomDoorsObjects2[i].getOpacity() - (300 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGame2Code.GDRoomDoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomDoorsObjects1.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDRoomDoorsObjects1[i].getOpacity() <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDRoomDoorsObjects1[k] = gdjs.MainGame2Code.GDRoomDoorsObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomDoorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDRoomDoorsObjects1 */
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomDoorsObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomDoorsObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGame2Code.GDRoomObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGame2Code.GDRoomTrapsObjects2);

gdjs.MainGame2Code.forEachTotalCount3 = 0;
gdjs.MainGame2Code.forEachObjects3.length = 0;
gdjs.MainGame2Code.forEachCount0_3 = gdjs.MainGame2Code.GDRoomTrapsObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount0_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDRoomTrapsObjects2);
gdjs.MainGame2Code.forEachCount1_3 = gdjs.MainGame2Code.GDRoomFloorObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount1_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDRoomFloorObjects2);
gdjs.MainGame2Code.forEachCount2_3 = gdjs.MainGame2Code.GDRoomObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount2_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDRoomObjects2);
for (gdjs.MainGame2Code.forEachIndex3 = 0;gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachTotalCount3;++gdjs.MainGame2Code.forEachIndex3) {
gdjs.MainGame2Code.GDRoomObjects3.length = 0;

gdjs.MainGame2Code.GDRoomFloorObjects3.length = 0;

gdjs.MainGame2Code.GDRoomTrapsObjects3.length = 0;


if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3) {
    gdjs.MainGame2Code.GDRoomTrapsObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3) {
    gdjs.MainGame2Code.GDRoomFloorObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3+gdjs.MainGame2Code.forEachCount2_3) {
    gdjs.MainGame2Code.GDRoomObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.MainGame2Code.eventsList12(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects1ObjectsGDgdjs_9546MainGame2Code_9546GDSpiderObjects1ObjectsGDgdjs_9546MainGame2Code_9546GDImpObjects1Objects) <= 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomFloorObjects2Objects, (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointY("")), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDRoomFloorObjects2.length;i<l;++i) {
    if ( !(gdjs.MainGame2Code.GDRoomFloorObjects2[i].isCollidingWithPoint((( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointY("")))) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDRoomFloorObjects2[k] = gdjs.MainGame2Code.GDRoomFloorObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDRoomFloorObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35172820);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DangerLevelCount"), gdjs.MainGame2Code.GDDangerLevelCountObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).add(0.5);
}{runtimeScene.getScene().getVariables().get("DangerLevelRounded").setNumber(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2))));
}{for(var i = 0, len = gdjs.MainGame2Code.GDDangerLevelCountObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDDangerLevelCountObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("DangerLevelRounded")));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects1Objects) == 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList16 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList17 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList18 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGame2Code.GDUpgradesObjects2);

gdjs.MainGame2Code.forEachTotalCount3 = 0;
gdjs.MainGame2Code.forEachObjects3.length = 0;
gdjs.MainGame2Code.forEachCount0_3 = gdjs.MainGame2Code.GDGhostObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount0_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDGhostObjects2);
gdjs.MainGame2Code.forEachCount1_3 = gdjs.MainGame2Code.GDPlayerObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount1_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.MainGame2Code.forEachCount2_3 = gdjs.MainGame2Code.GDBulletObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount2_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDBulletObjects2);
gdjs.MainGame2Code.forEachCount3_3 = gdjs.MainGame2Code.GDUpgradesObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount3_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDUpgradesObjects2);
gdjs.MainGame2Code.forEachCount4_3 = gdjs.MainGame2Code.GDSpiderObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount4_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDSpiderObjects2);
gdjs.MainGame2Code.forEachCount5_3 = gdjs.MainGame2Code.GDImpObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount5_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDImpObjects2);
gdjs.MainGame2Code.forEachCount6_3 = gdjs.MainGame2Code.GDGhostOrbObjects2.length;
gdjs.MainGame2Code.forEachTotalCount3 += gdjs.MainGame2Code.forEachCount6_3;
gdjs.MainGame2Code.forEachObjects3.push.apply(gdjs.MainGame2Code.forEachObjects3,gdjs.MainGame2Code.GDGhostOrbObjects2);
for (gdjs.MainGame2Code.forEachIndex3 = 0;gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachTotalCount3;++gdjs.MainGame2Code.forEachIndex3) {
gdjs.MainGame2Code.GDBulletObjects3.length = 0;

gdjs.MainGame2Code.GDGhostObjects3.length = 0;

gdjs.MainGame2Code.GDGhostOrbObjects3.length = 0;

gdjs.MainGame2Code.GDImpObjects3.length = 0;

gdjs.MainGame2Code.GDPlayerObjects3.length = 0;

gdjs.MainGame2Code.GDSpiderObjects3.length = 0;

gdjs.MainGame2Code.GDUpgradesObjects3.length = 0;


if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3) {
    gdjs.MainGame2Code.GDGhostObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3) {
    gdjs.MainGame2Code.GDPlayerObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3+gdjs.MainGame2Code.forEachCount2_3) {
    gdjs.MainGame2Code.GDBulletObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3+gdjs.MainGame2Code.forEachCount2_3+gdjs.MainGame2Code.forEachCount3_3) {
    gdjs.MainGame2Code.GDUpgradesObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3+gdjs.MainGame2Code.forEachCount2_3+gdjs.MainGame2Code.forEachCount3_3+gdjs.MainGame2Code.forEachCount4_3) {
    gdjs.MainGame2Code.GDSpiderObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3+gdjs.MainGame2Code.forEachCount2_3+gdjs.MainGame2Code.forEachCount3_3+gdjs.MainGame2Code.forEachCount4_3+gdjs.MainGame2Code.forEachCount5_3) {
    gdjs.MainGame2Code.GDImpObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
else if (gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.forEachCount0_3+gdjs.MainGame2Code.forEachCount1_3+gdjs.MainGame2Code.forEachCount2_3+gdjs.MainGame2Code.forEachCount3_3+gdjs.MainGame2Code.forEachCount4_3+gdjs.MainGame2Code.forEachCount5_3+gdjs.MainGame2Code.forEachCount6_3) {
    gdjs.MainGame2Code.GDGhostOrbObjects3.push(gdjs.MainGame2Code.forEachObjects3[gdjs.MainGame2Code.forEachIndex3]);
}
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setZOrder((gdjs.MainGame2Code.GDGhostObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].setZOrder((gdjs.MainGame2Code.GDPlayerObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects3[i].setZOrder((gdjs.MainGame2Code.GDBulletObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects3[i].setZOrder((gdjs.MainGame2Code.GDUpgradesObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].setZOrder((gdjs.MainGame2Code.GDSpiderObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].setZOrder((gdjs.MainGame2Code.GDImpObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].setZOrder((gdjs.MainGame2Code.GDGhostOrbObjects3[i].getPointY("")));
}
}}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects2[i].setZOrder((( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointY("")) + 1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);

for (gdjs.MainGame2Code.forEachIndex3 = 0;gdjs.MainGame2Code.forEachIndex3 < gdjs.MainGame2Code.GDRoomFloorObjects2.length;++gdjs.MainGame2Code.forEachIndex3) {
gdjs.MainGame2Code.GDRoomFloorObjects3.length = 0;


gdjs.MainGame2Code.forEachTemporary3 = gdjs.MainGame2Code.GDRoomFloorObjects2[gdjs.MainGame2Code.forEachIndex3];
gdjs.MainGame2Code.GDRoomFloorObjects3.push(gdjs.MainGame2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomFloorObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomFloorObjects3[i].setZOrder((gdjs.MainGame2Code.GDRoomFloorObjects3[i].getPointY("")) - 3000);
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGame2Code.GDRoomTrapsObjects1);

for (gdjs.MainGame2Code.forEachIndex2 = 0;gdjs.MainGame2Code.forEachIndex2 < gdjs.MainGame2Code.GDRoomTrapsObjects1.length;++gdjs.MainGame2Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGame2Code.GDRoomFloorObjects2);
gdjs.MainGame2Code.GDRoomTrapsObjects2.length = 0;


gdjs.MainGame2Code.forEachTemporary2 = gdjs.MainGame2Code.GDRoomTrapsObjects1[gdjs.MainGame2Code.forEachIndex2];
gdjs.MainGame2Code.GDRoomTrapsObjects2.push(gdjs.MainGame2Code.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.MainGame2Code.GDRoomTrapsObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRoomTrapsObjects2[i].setZOrder((( gdjs.MainGame2Code.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDRoomFloorObjects2[0].getPointY("")) - 2000);
}
}}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects2Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGame2Code.GDRoomDoorsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects3Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGame2Code.GDPick_9595UpsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects3Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGame2Code.GDPick_9595UpsObjects3});
gdjs.MainGame2Code.eventsList20 = function(runtimeScene) {

{

/* Reuse gdjs.MainGame2Code.GDPlayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Health")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects4[k] = gdjs.MainGame2Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGame2Code.GDHealthBarObjects4);
/* Reuse gdjs.MainGame2Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects4[i].getBehavior("Health").Heal(Math.ceil(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Health")) / 10), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}{for(var i = 0, len = gdjs.MainGame2Code.GDHealthBarObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDHealthBarObjects4[i].SetValue((( gdjs.MainGame2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainGame2Code.eventsList21 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPick_9595UpsObjects3, gdjs.MainGame2Code.GDPick_9595UpsObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPick_9595UpsObjects4.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPick_9595UpsObjects4[i].isCurrentAnimationName("HealthOrb") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPick_9595UpsObjects4[k] = gdjs.MainGame2Code.GDPick_9595UpsObjects4[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPick_9595UpsObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects4 */
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects3, gdjs.MainGame2Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects4[i].resetTimer("PickUpPitch");
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList20(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPick_9595UpsObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPick_9595UpsObjects3[i].isCurrentAnimationName("PointOrb") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPick_9595UpsObjects3[k] = gdjs.MainGame2Code.GDPick_9595UpsObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPick_9595UpsObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects3 */
gdjs.copyArray(runtimeScene.getObjects("TotalPointsCount"), gdjs.MainGame2Code.GDTotalPointsCountObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.MainGame2Code.GDTotalPointsCountObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDTotalPointsCountObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDTotalPointsCountObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDTotalPointsCountObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 3, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainGame2Code.eventsList22 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects3 */
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects3Objects, 10, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "PickUp.wav", false, 10, (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGame2Code.GDPlayerObjects3[0].getVariables()).getFromIndex(5))));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(5)).add(0.05);
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList23 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGame2Code.GDPick_9595UpsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects3Objects, 80, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects3 */
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects3[i].addForceTowardPosition((( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointY("")), 100, 0);
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList22(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("PickUpPitch") > 1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects2[k] = gdjs.MainGame2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(5)).setNumber(1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].removeTimer("PickUpPitch");
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradesObjects2Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGame2Code.GDUpgradesObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects3Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGame2Code.GDUpgradeIconsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects3Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGame2Code.GDUpgradeIconsObjects3});
gdjs.MainGame2Code.eventsList24 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradesObjects2, gdjs.MainGame2Code.GDUpgradesObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradesObjects3[i].isCurrentAnimationName("HealthUp") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradesObjects3[k] = gdjs.MainGame2Code.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradesObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGame2Code.GDHealthBarObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Health").add(3);
}{for(var i = 0, len = gdjs.MainGame2Code.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDHealthBarObjects3[i].SetMaxValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Health")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradesObjects2, gdjs.MainGame2Code.GDUpgradesObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradesObjects3[i].isCurrentAnimationName("Armor") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradesObjects3[k] = gdjs.MainGame2Code.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradesObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Defense").add(2);
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradesObjects2, gdjs.MainGame2Code.GDUpgradesObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradesObjects3[i].isCurrentAnimationName("FireRate") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradesObjects3[k] = gdjs.MainGame2Code.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradesObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects3);
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects3[i].getBehavior("FireBullet").SetCooldownOp(gdjs.MainGame2Code.GDGunObjects3[i].getBehavior("FireBullet").Cooldown((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) * (0.85), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].setVariableBoolean(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(1), true);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradesObjects2, gdjs.MainGame2Code.GDUpgradesObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradesObjects3[i].isCurrentAnimationName("Power") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradesObjects3[k] = gdjs.MainGame2Code.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradesObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").add(2);
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].setVariableBoolean(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(1), true);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradesObjects2, gdjs.MainGame2Code.GDUpgradesObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradesObjects3[i].isCurrentAnimationName("Speed") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradesObjects3[k] = gdjs.MainGame2Code.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradesObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Speedcap").add(0.5);
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("SpeedMax").add(12 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Speedcap")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDUpgradesObjects2, gdjs.MainGame2Code.GDUpgradesObjects3);

gdjs.MainGame2Code.GDUpgradeIconsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects3Objects, 16 + (32 * (gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects3Objects))), 64, "UI");
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradeIconsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradeIconsObjects3[i].setAnimationName((( gdjs.MainGame2Code.GDUpgradesObjects3.length === 0 ) ? "" :gdjs.MainGame2Code.GDUpgradesObjects3[0].getAnimationName()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradeIconsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradeIconsObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 5, 5, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.MainGame2Code.GDUpgradesObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgradesObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgradesObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.eventsList25 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGame2Code.GDUpgradesObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradesObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrade.wav", false, 35, 0.8);
}
{ //Subevents
gdjs.MainGame2Code.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList26 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.MainGame2Code.GDMovementJoystickObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDMovementJoystickObjects4.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDMovementJoystickObjects4[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDMovementJoystickObjects4[k] = gdjs.MainGame2Code.GDMovementJoystickObjects4[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDMovementJoystickObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDMovementJoystickObjects4 */
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects4[i].addPolarForce((( gdjs.MainGame2Code.GDMovementJoystickObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDMovementJoystickObjects4[0].JoystickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("SpeedMax")) * (( gdjs.MainGame2Code.GDMovementJoystickObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDMovementJoystickObjects4[0].JoystickForce((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), 0);
}
}}

}


};gdjs.MainGame2Code.eventsList27 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects4.length;i<l;++i) {
    if ( !(gdjs.MainGame2Code.GDPlayerObjects4[i].hasNoForces()) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects4[k] = gdjs.MainGame2Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35239260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects4[i].setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects3[i].hasNoForces() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects3[k] = gdjs.MainGame2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35239948);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].setAnimationName("Idle");
}
}}

}


};gdjs.MainGame2Code.eventsList28 = function(runtimeScene) {

{


gdjs.MainGame2Code.eventsList26(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList27(runtimeScene);
}


};gdjs.MainGame2Code.eventsList29 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AimingJoystick"), gdjs.MainGame2Code.GDAimingJoystickObjects4);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects4);
{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects4[i].setAngle((( gdjs.MainGame2Code.GDAimingJoystickObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDAimingJoystickObjects4[0].JoystickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AimingJoystick"), gdjs.MainGame2Code.GDAimingJoystickObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(gdjs.evtTools.common.angleDifference(180, (( gdjs.MainGame2Code.GDAimingJoystickObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDAimingJoystickObjects4[0].JoystickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))))) < 90);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects4);
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects4);

{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects4[i].flipY(true);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects4[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AimingJoystick"), gdjs.MainGame2Code.GDAimingJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (Math.abs(gdjs.evtTools.common.angleDifference(0, (( gdjs.MainGame2Code.GDAimingJoystickObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDAimingJoystickObjects3[0].JoystickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))))) < 90);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects3);
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects3[i].flipY(false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].flipX(false);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDParticle_95959595RecoilDustObjects3Objects = Hashtable.newFrom({"Particle_RecoilDust": gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects3});
gdjs.MainGame2Code.eventsList30 = function(runtimeScene) {

{

/* Reuse gdjs.MainGame2Code.GDBulletObjects3 */
/* Reuse gdjs.MainGame2Code.GDGunObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDBulletObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDBulletObjects3[i].getX() == (( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getPointX("BulletSpawn")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDBulletObjects3[k] = gdjs.MainGame2Code.GDBulletObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDBulletObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDBulletObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDBulletObjects3[i].getY() == (( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getPointY("BulletSpawn")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDBulletObjects3[k] = gdjs.MainGame2Code.GDBulletObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDBulletObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDBulletObjects3 */
/* Reuse gdjs.MainGame2Code.GDGunObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects3[i].setZOrder((( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getZOrder()) - 1);
}
}}

}


};gdjs.MainGame2Code.eventsList31 = function(runtimeScene) {

{

/* Reuse gdjs.MainGame2Code.GDGunObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGunObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGunObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGunObjects3[k] = gdjs.MainGame2Code.GDGunObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGunObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGunObjects3 */
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);

gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects3[i].setAnimationFrame(0);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.1, 3, 3, 2, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Shoot.wav", false, 30, gdjs.randomFloatInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 0, 0, "", 0, 0.2, 0, 1, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].resetTimer("Recoil");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].returnVariable(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(3)).setNumber((( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getAngle()) + 180);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDParticle_95959595RecoilDustObjects3Objects, (( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getPointX("BulletSpawn")), (( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getPointY("BulletSpawn")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects3[i].setZOrder((( gdjs.MainGame2Code.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGunObjects3[0].getZOrder()) + 100);
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList32 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("AimingJoystick"), gdjs.MainGame2Code.GDAimingJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDAimingJoystickObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDAimingJoystickObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDAimingJoystickObjects3[k] = gdjs.MainGame2Code.GDAimingJoystickObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDAimingJoystickObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects3[i].getBehavior("FireBullet").Fire((gdjs.MainGame2Code.GDGunObjects3[i].getPointX("BulletSpawn")), (gdjs.MainGame2Code.GDGunObjects3[i].getPointY("BulletSpawn")), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, (gdjs.MainGame2Code.GDGunObjects3[i].getAngle()), 240, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects3Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects3Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGame2Code.GDRoomDoorsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder3Objects3Objects = Hashtable.newFrom({"GrassBorder3": gdjs.MainGame2Code.GDGrassBorder3Objects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects3Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects3Objects = Hashtable.newFrom({"GrassBorder2": gdjs.MainGame2Code.GDGrassBorder2Objects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects3Objects = Hashtable.newFrom({"GrassBorder": gdjs.MainGame2Code.GDGrassBorderObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects3Objects = Hashtable.newFrom({"Tree": gdjs.MainGame2Code.GDTreeObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDWallObjects3Objects = Hashtable.newFrom({"Wall": gdjs.MainGame2Code.GDWallObjects3});
gdjs.MainGame2Code.eventsList33 = function(runtimeScene) {

{


gdjs.MainGame2Code.eventsList29(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList32(runtimeScene);
}


{



}


{

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects2, gdjs.MainGame2Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Recoil") <= 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects3[k] = gdjs.MainGame2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects3[i].getVariables().getFromIndex(3))), 25, 0);
}
}}

}


{



}


{

gdjs.MainGame2Code.GDBulletObjects2.length = 0;

gdjs.MainGame2Code.GDGrassBorderObjects2.length = 0;

gdjs.MainGame2Code.GDGrassBorder2Objects2.length = 0;

gdjs.MainGame2Code.GDGrassBorder3Objects2.length = 0;

gdjs.MainGame2Code.GDGrassBorder4Objects2.length = 0;

gdjs.MainGame2Code.GDRoomObjects2.length = 0;

gdjs.MainGame2Code.GDRoomDoorsObjects2.length = 0;

gdjs.MainGame2Code.GDTreeObjects2.length = 0;

gdjs.MainGame2Code.GDWallObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.MainGame2Code.GDBulletObjects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects2_1final.length = 0;
gdjs.MainGame2Code.GDRoomObjects2_1final.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects2_1final.length = 0;
gdjs.MainGame2Code.GDTreeObjects2_1final.length = 0;
gdjs.MainGame2Code.GDWallObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGame2Code.GDRoomObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomObjects2_1final.indexOf(gdjs.MainGame2Code.GDRoomObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDRoomObjects2_1final.push(gdjs.MainGame2Code.GDRoomObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGame2Code.GDRoomDoorsObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomDoorsObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomDoorsObjects2_1final.indexOf(gdjs.MainGame2Code.GDRoomDoorsObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDRoomDoorsObjects2_1final.push(gdjs.MainGame2Code.GDRoomDoorsObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder3"), gdjs.MainGame2Code.GDGrassBorder3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorder3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorder3Objects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorder3Objects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorder3Objects2_1final.push(gdjs.MainGame2Code.GDGrassBorder3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorder4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorder4Objects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorder4Objects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorder4Objects2_1final.push(gdjs.MainGame2Code.GDGrassBorder4Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder2"), gdjs.MainGame2Code.GDGrassBorder2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorder2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorder2Objects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorder2Objects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorder2Objects2_1final.push(gdjs.MainGame2Code.GDGrassBorder2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder"), gdjs.MainGame2Code.GDGrassBorderObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorderObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorderObjects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorderObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorderObjects2_1final.push(gdjs.MainGame2Code.GDGrassBorderObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tree"), gdjs.MainGame2Code.GDTreeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDTreeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDTreeObjects2_1final.indexOf(gdjs.MainGame2Code.GDTreeObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDTreeObjects2_1final.push(gdjs.MainGame2Code.GDTreeObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.MainGame2Code.GDWallObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDWallObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDBulletObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDBulletObjects2_1final.indexOf(gdjs.MainGame2Code.GDBulletObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDBulletObjects2_1final.push(gdjs.MainGame2Code.GDBulletObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDWallObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDWallObjects2_1final.indexOf(gdjs.MainGame2Code.GDWallObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDWallObjects2_1final.push(gdjs.MainGame2Code.GDWallObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDBulletObjects2_1final, gdjs.MainGame2Code.GDBulletObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorderObjects2_1final, gdjs.MainGame2Code.GDGrassBorderObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorder2Objects2_1final, gdjs.MainGame2Code.GDGrassBorder2Objects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorder3Objects2_1final, gdjs.MainGame2Code.GDGrassBorder3Objects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorder4Objects2_1final, gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects2_1final, gdjs.MainGame2Code.GDRoomObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomDoorsObjects2_1final, gdjs.MainGame2Code.GDRoomDoorsObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDTreeObjects2_1final, gdjs.MainGame2Code.GDTreeObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDWallObjects2_1final, gdjs.MainGame2Code.GDWallObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDBulletObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.eventsList34 = function(runtimeScene) {

{


gdjs.MainGame2Code.eventsList28(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList33(runtimeScene);
}


};gdjs.MainGame2Code.eventsList35 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects2[k] = gdjs.MainGame2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "PauseLayer"));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects2Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects2Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGame2Code.GDRoomTrapsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects2Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDParticle_95959595DeathObjects1Objects = Hashtable.newFrom({"Particle_Death": gdjs.MainGame2Code.GDParticle_9595DeathObjects1});
gdjs.MainGame2Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGame2Code.GDGhostOrbObjects1, gdjs.MainGame2Code.GDGhostOrbObjects2);

gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1, gdjs.MainGame2Code.GDPlayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects2Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostOrbObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

/* Reuse gdjs.MainGame2Code.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects1[k] = gdjs.MainGame2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects1);
/* Reuse gdjs.MainGame2Code.GDPlayerObjects1 */
gdjs.MainGame2Code.GDParticle_9595DeathObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDParticle_95959595DeathObjects1Objects, (( gdjs.MainGame2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects1[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDParticle_9595DeathObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDParticle_9595DeathObjects1[i].setZOrder((( gdjs.MainGame2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects1[0].getPointY("")) + 10000);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "DeathSound.wav", false, 50, 1);
}}

}


};gdjs.MainGame2Code.eventsList37 = function(runtimeScene) {

{



}


{

gdjs.MainGame2Code.GDGhostOrbObjects1.length = 0;

gdjs.MainGame2Code.GDPlayerObjects1.length = 0;

gdjs.MainGame2Code.GDRoomTrapsObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.MainGame2Code.GDGhostOrbObjects1_1final.length = 0;
gdjs.MainGame2Code.GDPlayerObjects1_1final.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects2Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects2.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects1_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects2[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects1_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects1_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects2[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects1_1final.push(gdjs.MainGame2Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGame2Code.GDRoomTrapsObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects2Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDPlayerObjects1_1final.indexOf(gdjs.MainGame2Code.GDPlayerObjects2[j]) === -1 )
            gdjs.MainGame2Code.GDPlayerObjects1_1final.push(gdjs.MainGame2Code.GDPlayerObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomTrapsObjects2.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomTrapsObjects1_1final.indexOf(gdjs.MainGame2Code.GDRoomTrapsObjects2[j]) === -1 )
            gdjs.MainGame2Code.GDRoomTrapsObjects1_1final.push(gdjs.MainGame2Code.GDRoomTrapsObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDGhostOrbObjects1_1final, gdjs.MainGame2Code.GDGhostOrbObjects1);
gdjs.copyArray(gdjs.MainGame2Code.GDPlayerObjects1_1final, gdjs.MainGame2Code.GDPlayerObjects1);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomTrapsObjects1_1final, gdjs.MainGame2Code.GDRoomTrapsObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects1[k] = gdjs.MainGame2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGame2Code.GDHealthBarObjects1);
/* Reuse gdjs.MainGame2Code.GDPlayerObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "PlayerHurt.wav", false, 50, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("Flash").Flash(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("Health").Hit(Math.max(1, Math.ceil(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("DangerLevelRounded")) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Defense")))), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}{for(var i = 0, len = gdjs.MainGame2Code.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDHealthBarObjects1[i].SetValue((( gdjs.MainGame2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList38 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGame2Code.GDRoomObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGame2Code.GDRoomDoorsObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects2Objects, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects2[i].setPosition((( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("GunSpot")),(( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointY("GunSpot")));
}
}}

}


{


gdjs.MainGame2Code.eventsList23(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList25(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList35(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList37(runtimeScene);
}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects2Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGame2Code.GDRoomTrapsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects2Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGame2Code.GDRoomTrapsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects2Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects3Objects = Hashtable.newFrom({"GoldenImp": gdjs.MainGame2Code.GDGoldenImpObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects3Objects = Hashtable.newFrom({"GoldenImp": gdjs.MainGame2Code.GDGoldenImpObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects5Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects5});
gdjs.MainGame2Code.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDGoldenImpObjects4, gdjs.MainGame2Code.GDGoldenImpObjects5);

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects5);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects5);
gdjs.MainGame2Code.GDGhostOrbObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects5Objects, (( gdjs.MainGame2Code.GDGoldenImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGoldenImpObjects5[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGame2Code.GDGoldenImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGoldenImpObjects5[0].getPointY("GhostOrbSpawn")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects5[i].setZOrder((( gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects5[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects5[i].addPolarForce(gdjs.evtTools.common.angleBetweenPositions((( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) + 5, (( gdjs.MainGame2Code.GDGoldenImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGoldenImpObjects5[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGame2Code.GDGoldenImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGoldenImpObjects5[0].getPointY("GhostOrbSpawn"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGame2Code.GDGoldenImpObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGame2Code.GDGoldenImpObjects5[0].getVariables()).get("Spread"))), 45, 1);
}
}}

}


};gdjs.MainGame2Code.eventsList40 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDGoldenImpObjects3, gdjs.MainGame2Code.GDGoldenImpObjects4);

{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects4[i].returnVariable(gdjs.MainGame2Code.GDGoldenImpObjects4[i].getVariables().get("Spread")).setNumber(140);
}
}}

}


{


const repeatCount4 = 15;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.MainGame2Code.GDGoldenImpObjects3, gdjs.MainGame2Code.GDGoldenImpObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects4[i].returnVariable(gdjs.MainGame2Code.GDGoldenImpObjects4[i].getVariables().get("Spread")).add(10);
}
}
{ //Subevents: 
gdjs.MainGame2Code.eventsList39(runtimeScene);} //Subevents end.
}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects3Objects = Hashtable.newFrom({"GoldenImp": gdjs.MainGame2Code.GDGoldenImpObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGame2Code.GDEnemyDamageTextObjects3});
gdjs.MainGame2Code.eventsList41 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects3[i].isCurrentAnimationName("GoldIdle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects3[k] = gdjs.MainGame2Code.GDGoldenImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, 250, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGoldenImpObjects3 */
/* Reuse gdjs.MainGame2Code.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].addForceTowardObject((gdjs.MainGame2Code.GDPlayerObjects3.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects3[0] : null), 18, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, 140, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects3[i].isCurrentAnimationName("GoldIdle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects3[k] = gdjs.MainGame2Code.GDGoldenImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGoldenImpObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].setAnimationName("GoldCharging");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ImpHop.wav", false, 10, gdjs.randomFloatInRange(1, 1.2));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects3[i].isCurrentAnimationName("GoldCharging") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects3[k] = gdjs.MainGame2Code.GDGoldenImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects3[k] = gdjs.MainGame2Code.GDGoldenImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGoldenImpObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ImpStomp.wav", false, 20, gdjs.randomFloatInRange(1, 1.2));
}
{ //Subevents
gdjs.MainGame2Code.eventsList40(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects3[i].isCurrentAnimationName("Resting") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects3[k] = gdjs.MainGame2Code.GDGoldenImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects3[k] = gdjs.MainGame2Code.GDGoldenImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGoldenImpObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].setAnimationName("GoldIdle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDBulletObjects3 */
/* Reuse gdjs.MainGame2Code.GDGoldenImpObjects3 */
gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 2, 2, 2, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects, (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGame2Code.GDGoldenImpObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGoldenImpObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects3[i].returnVariable(gdjs.MainGame2Code.GDGoldenImpObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGoldenImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGoldenImpObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGoldenImpObjects2[k] = gdjs.MainGame2Code.GDGoldenImpObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGoldenImpObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGoldenImpObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDGoldenImpObjects2[i].getVariables().get("KnockBackAngle"))), 15, 0);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects3Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects3Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGame2Code.GDEnemyDamageTextObjects3});
gdjs.MainGame2Code.eventsList42 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].isCurrentAnimationName("Idle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].addForceTowardObject((gdjs.MainGame2Code.GDPlayerObjects3.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects3[0] : null), 87, 0);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, 120, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].isCurrentAnimationName("Idle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setAnimationName("Charging");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].isCurrentAnimationName("Charging") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
gdjs.MainGame2Code.GDGhostOrbObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, (( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getPointY("GhostOrbSpawn")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].addForceTowardPosition((( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointY("")) + 5, 240, 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].setZOrder((( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getZOrder()) - 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "GhostFire.wav", false, 10, gdjs.randomFloatInRange(0.7, 0.9));
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].resetTimer("GhostTimer1");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].isCurrentAnimationName("Resting") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
gdjs.MainGame2Code.GDGhostOrbObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setAnimationName("Idle");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, (( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getPointY("GhostOrbSpawn")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].addForceTowardPosition((( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects3[0].getPointY("")) + 5, 240, 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].setZOrder((( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getZOrder()) - 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "GhostFire.wav", false, 10, gdjs.randomFloatInRange(0.7, 0.9));
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects3[i].resetTimer("GhostTimer1");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDBulletObjects3 */
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].setAnimationName("Hurt");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 4, 4, 5, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects, (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects3[i].returnVariable(gdjs.MainGame2Code.GDGhostObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects2[k] = gdjs.MainGame2Code.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDGhostObjects2[i].getVariables().get("KnockBackAngle"))), 50, 0);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects4Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects4});
gdjs.MainGame2Code.eventsList43 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList44 = function(runtimeScene) {

{


const repeatCount4 = 7;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects4);
gdjs.copyArray(gdjs.MainGame2Code.GDSpiderObjects3, gdjs.MainGame2Code.GDSpiderObjects4);

gdjs.MainGame2Code.GDGhostOrbObjects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects4Objects, (( gdjs.MainGame2Code.GDSpiderObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDSpiderObjects4[0].getPointX("GhostOrbSpawn")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("i"))).getChild("X")), (( gdjs.MainGame2Code.GDSpiderObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDSpiderObjects4[0].getPointY("GhostOrbSpawn")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("i"))).getChild("Y")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects4[i].addForceTowardPosition((( gdjs.MainGame2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects4[0].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("i"))).getChild("X")), (( gdjs.MainGame2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects4[0].getPointY("")) + 5 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("i"))).getChild("Y")), 20, 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects4[i].setZOrder((( gdjs.MainGame2Code.GDSpiderObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDSpiderObjects4[0].getZOrder()) - 1);
}
}{runtimeScene.getScene().getVariables().get("i").add(1);
}}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGame2Code.GDEnemyDamageTextObjects3});
gdjs.MainGame2Code.eventsList45 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].isCurrentAnimationName("Idle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].addForceTowardObject((gdjs.MainGame2Code.GDPlayerObjects3.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects3[0] : null), 55, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, 15, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].isCurrentAnimationName("Idle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].setAnimationName("Charging");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].isCurrentAnimationName("Charging") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "SpiderNoise.wav", false, 10, gdjs.randomFloatInRange(1, 1.2));
}{runtimeScene.getScene().getVariables().get("i").setNumber(0);
}
{ //Subevents
gdjs.MainGame2Code.eventsList44(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].isCurrentAnimationName("Resting") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDBulletObjects3 */
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].setAnimationName("Hurt");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 3, 3, 4, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects, (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGame2Code.GDSpiderObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDSpiderObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects3[i].returnVariable(gdjs.MainGame2Code.GDSpiderObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects2[k] = gdjs.MainGame2Code.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDSpiderObjects2[i].getVariables().get("KnockBackAngle"))), 40, 0);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects3Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects5Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects5});
gdjs.MainGame2Code.eventsList46 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDImpObjects4, gdjs.MainGame2Code.GDImpObjects5);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects5);
gdjs.MainGame2Code.GDGhostOrbObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects5Objects, (( gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects5[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects5[0].getPointY("GhostOrbSpawn")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects5[i].setZOrder((( gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects5[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects5[i].addPolarForce(gdjs.evtTools.common.angleBetweenPositions((( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointX("")), (( gdjs.MainGame2Code.GDPlayerObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects5[0].getPointY("")) + 5, (( gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects5[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects5[0].getPointY("GhostOrbSpawn"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGame2Code.GDImpObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGame2Code.GDImpObjects5[0].getVariables()).get("Spread"))), 45, 1);
}
}}

}


};gdjs.MainGame2Code.eventsList47 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.MainGame2Code.GDImpObjects3, gdjs.MainGame2Code.GDImpObjects4);

{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects4[i].returnVariable(gdjs.MainGame2Code.GDImpObjects4[i].getVariables().get("Spread")).setNumber(140);
}
}}

}


{


const repeatCount4 = 7;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.MainGame2Code.GDImpObjects3, gdjs.MainGame2Code.GDImpObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects4[i].returnVariable(gdjs.MainGame2Code.GDImpObjects4[i].getVariables().get("Spread")).add(10);
}
}
{ //Subevents: 
gdjs.MainGame2Code.eventsList46(runtimeScene);} //Subevents end.
}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGame2Code.GDBulletObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects3Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGame2Code.GDEnemyDamageTextObjects3});
gdjs.MainGame2Code.eventsList48 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].isCurrentAnimationName("Idle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDImpObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].addForceTowardObject((gdjs.MainGame2Code.GDPlayerObjects3.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects3[0] : null), 18, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects3Objects, 140, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].isCurrentAnimationName("Idle") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDImpObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].setAnimationName("Charging");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ImpHop.wav", false, 10, gdjs.randomFloatInRange(1, 1.2));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].isCurrentAnimationName("Charging") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDImpObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ImpStomp.wav", false, 20, gdjs.randomFloatInRange(1, 1.2));
}
{ //Subevents
gdjs.MainGame2Code.eventsList47(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].isCurrentAnimationName("Resting") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].hasAnimationEndedLegacy() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDImpObjects3 */
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDBulletObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDBulletObjects3 */
/* Reuse gdjs.MainGame2Code.GDImpObjects3 */
gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 2, 2, 2, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects3Objects, (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGame2Code.GDImpObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDImpObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects3[i].returnVariable(gdjs.MainGame2Code.GDImpObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGame2Code.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects2[k] = gdjs.MainGame2Code.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDImpObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDImpObjects2[i].getVariables().get("KnockBackAngle"))), 15, 0);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects3Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGame2Code.GDPick_9595UpsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects4Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGame2Code.GDPick_9595UpsObjects4});
gdjs.MainGame2Code.eventsList49 = function(runtimeScene) {

};gdjs.MainGame2Code.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGame2Code.GDGhostObjects2, gdjs.MainGame2Code.GDGhostObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDImpObjects2, gdjs.MainGame2Code.GDImpObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDSpiderObjects2, gdjs.MainGame2Code.GDSpiderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects3[i].getVariableNumber(gdjs.MainGame2Code.GDGhostObjects3[i].getVariables().get("DropChance")) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDGhostObjects3[i].getVariables().get("DropChance_HealthOrb"))) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects3[k] = gdjs.MainGame2Code.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects3[i].getVariableNumber(gdjs.MainGame2Code.GDSpiderObjects3[i].getVariables().get("DropChance")) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDSpiderObjects3[i].getVariables().get("DropChance_HealthOrb"))) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects3[k] = gdjs.MainGame2Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects3[i].getVariableNumber(gdjs.MainGame2Code.GDImpObjects3[i].getVariables().get("DropChance")) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDImpObjects3[i].getVariables().get("DropChance_HealthOrb"))) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects3[k] = gdjs.MainGame2Code.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects3 */
/* Reuse gdjs.MainGame2Code.GDImpObjects3 */
/* Reuse gdjs.MainGame2Code.GDSpiderObjects3 */
gdjs.MainGame2Code.GDPick_9595UpsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects3Objects, (( gdjs.MainGame2Code.GDImpObjects3.length === 0 ) ? (( gdjs.MainGame2Code.GDSpiderObjects3.length === 0 ) ? (( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getPointX("")) :gdjs.MainGame2Code.GDSpiderObjects3[0].getPointX("")) :gdjs.MainGame2Code.GDImpObjects3[0].getPointX("")), (( gdjs.MainGame2Code.GDImpObjects3.length === 0 ) ? (( gdjs.MainGame2Code.GDSpiderObjects3.length === 0 ) ? (( gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects3[0].getPointY("")) :gdjs.MainGame2Code.GDSpiderObjects3[0].getPointY("")) :gdjs.MainGame2Code.GDImpObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects3[i].addPolarForce(gdjs.randomFloatInRange(0, 360), 40, 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects3[i].setAnimationName("HealthOrb");
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDGhostObjects2, gdjs.MainGame2Code.GDGhostObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDImpObjects2, gdjs.MainGame2Code.GDImpObjects3);

gdjs.copyArray(gdjs.MainGame2Code.GDSpiderObjects2, gdjs.MainGame2Code.GDSpiderObjects3);


const repeatCount4 = (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGame2Code.GDImpObjects3.length === 0 ) ? ((gdjs.MainGame2Code.GDSpiderObjects3.length === 0 ) ? ((gdjs.MainGame2Code.GDGhostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGame2Code.GDGhostObjects3[0].getVariables()) : gdjs.MainGame2Code.GDSpiderObjects3[0].getVariables()) : gdjs.MainGame2Code.GDImpObjects3[0].getVariables()).get("DropAmount_Points")));
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.MainGame2Code.GDGhostObjects3, gdjs.MainGame2Code.GDGhostObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDImpObjects3, gdjs.MainGame2Code.GDImpObjects4);

gdjs.copyArray(gdjs.MainGame2Code.GDSpiderObjects3, gdjs.MainGame2Code.GDSpiderObjects4);

gdjs.MainGame2Code.GDPick_9595UpsObjects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPick_95959595UpsObjects4Objects, (( gdjs.MainGame2Code.GDImpObjects4.length === 0 ) ? (( gdjs.MainGame2Code.GDSpiderObjects4.length === 0 ) ? (( gdjs.MainGame2Code.GDGhostObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects4[0].getPointX("")) :gdjs.MainGame2Code.GDSpiderObjects4[0].getPointX("")) :gdjs.MainGame2Code.GDImpObjects4[0].getPointX("")), (( gdjs.MainGame2Code.GDImpObjects4.length === 0 ) ? (( gdjs.MainGame2Code.GDSpiderObjects4.length === 0 ) ? (( gdjs.MainGame2Code.GDGhostObjects4.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects4[0].getPointY("")) :gdjs.MainGame2Code.GDSpiderObjects4[0].getPointY("")) :gdjs.MainGame2Code.GDImpObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects4[i].addPolarForce(gdjs.randomFloatInRange(0, 360), 50, 1);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.MainGame2Code.GDGhostObjects2 */
/* Reuse gdjs.MainGame2Code.GDImpObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGame2Code.GDPick_9595UpsObjects2);
/* Reuse gdjs.MainGame2Code.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects2[i].resetTimer("PickUps");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.eventsList51 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects2[k] = gdjs.MainGame2Code.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects2[k] = gdjs.MainGame2Code.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects2[k] = gdjs.MainGame2Code.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects2 */
/* Reuse gdjs.MainGame2Code.GDImpObjects2 */
/* Reuse gdjs.MainGame2Code.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].returnVariable(gdjs.MainGame2Code.GDGhostObjects2[i].getVariables().get("DropChance")).setNumber(gdjs.randomInRange(0, 100));
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].returnVariable(gdjs.MainGame2Code.GDSpiderObjects2[i].getVariables().get("DropChance")).setNumber(gdjs.randomInRange(0, 100));
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].returnVariable(gdjs.MainGame2Code.GDImpObjects2[i].getVariables().get("DropChance")).setNumber(gdjs.randomInRange(0, 100));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects3Objects = Hashtable.newFrom({"Room": gdjs.MainGame2Code.GDRoomObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects3Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGame2Code.GDRoomDoorsObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects3Objects = Hashtable.newFrom({"GrassBorder": gdjs.MainGame2Code.GDGrassBorderObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects3Objects = Hashtable.newFrom({"GrassBorder2": gdjs.MainGame2Code.GDGrassBorder2Objects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder3Objects3Objects = Hashtable.newFrom({"GrassBorder3": gdjs.MainGame2Code.GDGrassBorder3Objects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects3Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects3Objects = Hashtable.newFrom({"Tree": gdjs.MainGame2Code.GDTreeObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects1Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects1});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects1Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects1});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects1Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGame2Code.GDEnemyDamageTextObjects1});
gdjs.MainGame2Code.eventsList52 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects2[i].getX() < (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects2[k] = gdjs.MainGame2Code.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects2[i].getX() < (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects2[k] = gdjs.MainGame2Code.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects2[i].getX() < (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects2[k] = gdjs.MainGame2Code.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects2 */
/* Reuse gdjs.MainGame2Code.GDImpObjects2 */
/* Reuse gdjs.MainGame2Code.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects2[i].getX() > (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects2[k] = gdjs.MainGame2Code.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDSpiderObjects2[i].getX() > (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDSpiderObjects2[k] = gdjs.MainGame2Code.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDSpiderObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDImpObjects2[i].getX() > (( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDImpObjects2[k] = gdjs.MainGame2Code.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDImpObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostObjects2 */
/* Reuse gdjs.MainGame2Code.GDImpObjects2 */
/* Reuse gdjs.MainGame2Code.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].flipX(true);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGame2Code.GDRoomObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGame2Code.GDRoomTrapsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects, false);
}
for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects, false);
}
for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomTrapsObjects2Objects, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects2Objects, false);
}
}}

}


{


gdjs.MainGame2Code.eventsList41(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList42(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList45(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList48(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList51(runtimeScene);
}


{



}


{

gdjs.MainGame2Code.GDGhostOrbObjects2.length = 0;

gdjs.MainGame2Code.GDGrassBorderObjects2.length = 0;

gdjs.MainGame2Code.GDGrassBorder2Objects2.length = 0;

gdjs.MainGame2Code.GDGrassBorder3Objects2.length = 0;

gdjs.MainGame2Code.GDGrassBorder4Objects2.length = 0;

gdjs.MainGame2Code.GDRoomObjects2.length = 0;

gdjs.MainGame2Code.GDRoomDoorsObjects2.length = 0;

gdjs.MainGame2Code.GDTreeObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.MainGame2Code.GDGhostOrbObjects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects2_1final.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects2_1final.length = 0;
gdjs.MainGame2Code.GDRoomObjects2_1final.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects2_1final.length = 0;
gdjs.MainGame2Code.GDTreeObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGame2Code.GDRoomObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomObjects2_1final.indexOf(gdjs.MainGame2Code.GDRoomObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDRoomObjects2_1final.push(gdjs.MainGame2Code.GDRoomObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGame2Code.GDRoomDoorsObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDRoomDoorsObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDRoomDoorsObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDRoomDoorsObjects2_1final.indexOf(gdjs.MainGame2Code.GDRoomDoorsObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDRoomDoorsObjects2_1final.push(gdjs.MainGame2Code.GDRoomDoorsObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder"), gdjs.MainGame2Code.GDGrassBorderObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorderObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorderObjects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorderObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorderObjects2_1final.push(gdjs.MainGame2Code.GDGrassBorderObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder2"), gdjs.MainGame2Code.GDGrassBorder2Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorder2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorder2Objects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorder2Objects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorder2Objects2_1final.push(gdjs.MainGame2Code.GDGrassBorder2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder3"), gdjs.MainGame2Code.GDGrassBorder3Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder3Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorder3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorder3Objects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorder3Objects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorder3Objects2_1final.push(gdjs.MainGame2Code.GDGrassBorder3Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGrassBorder4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGrassBorder4Objects2_1final.indexOf(gdjs.MainGame2Code.GDGrassBorder4Objects3[j]) === -1 )
            gdjs.MainGame2Code.GDGrassBorder4Objects2_1final.push(gdjs.MainGame2Code.GDGrassBorder4Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tree"), gdjs.MainGame2Code.GDTreeObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects3Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.MainGame2Code.GDGhostOrbObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGame2Code.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDGhostOrbObjects2_1final.push(gdjs.MainGame2Code.GDGhostOrbObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.MainGame2Code.GDTreeObjects3.length; j < jLen ; ++j) {
        if ( gdjs.MainGame2Code.GDTreeObjects2_1final.indexOf(gdjs.MainGame2Code.GDTreeObjects3[j]) === -1 )
            gdjs.MainGame2Code.GDTreeObjects2_1final.push(gdjs.MainGame2Code.GDTreeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGame2Code.GDGhostOrbObjects2_1final, gdjs.MainGame2Code.GDGhostOrbObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorderObjects2_1final, gdjs.MainGame2Code.GDGrassBorderObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorder2Objects2_1final, gdjs.MainGame2Code.GDGrassBorder2Objects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorder3Objects2_1final, gdjs.MainGame2Code.GDGrassBorder3Objects2);
gdjs.copyArray(gdjs.MainGame2Code.GDGrassBorder4Objects2_1final, gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomObjects2_1final, gdjs.MainGame2Code.GDRoomObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDRoomDoorsObjects2_1final, gdjs.MainGame2Code.GDRoomDoorsObjects2);
gdjs.copyArray(gdjs.MainGame2Code.GDTreeObjects2_1final, gdjs.MainGame2Code.GDTreeObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostOrbObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGame2Code.GDPick_9595UpsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPick_9595UpsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPick_9595UpsObjects2[i].getTimerElapsedTimeInSecondsOrNaN("PickUps") > 0.2 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPick_9595UpsObjects2[k] = gdjs.MainGame2Code.GDPick_9595UpsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPick_9595UpsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35318124);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects2[i].clearForces();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGame2Code.GDPick_9595UpsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPick_9595UpsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPick_9595UpsObjects2[i].getTimerElapsedTimeInSecondsOrNaN("PickUps") > 5 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPick_9595UpsObjects2[k] = gdjs.MainGame2Code.GDPick_9595UpsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPick_9595UpsObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDPick_9595UpsObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDPick_9595UpsObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPick_9595UpsObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects1Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostObjects1.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostObjects1[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostObjects1[k] = gdjs.MainGame2Code.GDGhostObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDGhostOrbObjects1.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDGhostOrbObjects1[i].getTimerElapsedTimeInSecondsOrNaN("GhostTimer1") >= 0.3 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDGhostOrbObjects1[k] = gdjs.MainGame2Code.GDGhostOrbObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDGhostOrbObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects1);
/* Reuse gdjs.MainGame2Code.GDGhostObjects1 */
/* Reuse gdjs.MainGame2Code.GDGhostOrbObjects1 */
gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects1[i].setAnimationName("Hurt");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 4, 4, 5, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects1[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDEnemyDamageTextObjects1Objects, (( gdjs.MainGame2Code.GDBulletObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects1[0].getPointX("")), (( gdjs.MainGame2Code.GDBulletObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects1[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects1[i].setZOrder((( gdjs.MainGame2Code.GDGhostObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDGhostObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects1[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects1[i].returnVariable(gdjs.MainGame2Code.GDGhostObjects1[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGame2Code.GDBulletObjects1.length === 0 ) ? 0 :gdjs.MainGame2Code.GDBulletObjects1[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.eventsList53 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnemyDamageText"), gdjs.MainGame2Code.GDEnemyDamageTextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects2[i].setOpacity(gdjs.MainGame2Code.GDEnemyDamageTextObjects2[i].getOpacity() - (150 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyDamageText"), gdjs.MainGame2Code.GDEnemyDamageTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDEnemyDamageTextObjects1[i].getOpacity() <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDEnemyDamageTextObjects1[k] = gdjs.MainGame2Code.GDEnemyDamageTextObjects1[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDEnemyDamageTextObjects1 */
{for(var i = 0, len = gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDEnemyDamageTextObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects1});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595ButtonObjects3Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGame2Code.GDReset_9595ButtonObjects3});
gdjs.MainGame2Code.eventsList54 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.MainGame2Code.GDReset_9595ButtonObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595ButtonObjects3Objects) == 1;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "MenuButtomPress.wav", false, 60, 0.8);
}}

}


};gdjs.MainGame2Code.asyncCallback35330636 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Darkening"), gdjs.MainGame2Code.GDDarkeningObjects3);
gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGame2Code.GDReset_9595ButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDDarkeningObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDDarkeningObjects3[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDDarkeningObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDDarkeningObjects3[i].setCenterXInScene((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2));
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Reset");
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595ButtonObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595ButtonObjects3[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDReset_9595ButtonObjects3[i].getWidth()) / 2));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3[i].getWidth()) / 2));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595ButtonObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595ButtonObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 3, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 3, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDDarkeningObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDDarkeningObjects3[i].setOpacity(100);
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainGame2Code.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.MainGame2Code.asyncCallback35330636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595ButtonObjects3Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGame2Code.GDReset_9595ButtonObjects3});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595ButtonObjects3Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGame2Code.GDReset_9595ButtonObjects3});
gdjs.MainGame2Code.asyncCallback35340492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}}
gdjs.MainGame2Code.eventsList56 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0), (runtimeScene) => (gdjs.MainGame2Code.asyncCallback35340492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGame2Code.asyncCallback35338420 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Reset_Timer"), gdjs.MainGame2Code.GDReset_9595TimerObjects5);

{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects5[i].setString("1");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects5[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDReset_9595TimerObjects5[i].getWidth()) / 2));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ResetTimer.wav", false, 50, 1.2);
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects5.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects5[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 7, 7, 7, 0.08, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList56(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainGame2Code.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.MainGame2Code.GDReset_9595TimerObjects4) asyncObjectsList.addObject("Reset_Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0), (runtimeScene) => (gdjs.MainGame2Code.asyncCallback35338420(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGame2Code.asyncCallback35338028 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Reset_Timer"), gdjs.MainGame2Code.GDReset_9595TimerObjects4);

{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects4[i].setString("2");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects4[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDReset_9595TimerObjects4[i].getWidth()) / 2));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ResetTimer.wav", false, 40, 1);
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects4.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 4, 4, 4, 0.08, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainGame2Code.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainGame2Code.GDReset_9595TimerObjects3) asyncObjectsList.addObject("Reset_Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0), (runtimeScene) => (gdjs.MainGame2Code.asyncCallback35338028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595LeaderboardObjects2Objects = Hashtable.newFrom({"Reset_Leaderboard": gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2});
gdjs.MainGame2Code.eventsList59 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGame2Code.GDReset_9595ButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595ButtonObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35335492);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDReset_9595ButtonObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595ButtonObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595ButtonObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Death");
}{gdjs.evtTools.sound.playSound(runtimeScene, "MenuButtomPress.wav", false, 30, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGame2Code.GDReset_9595ButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595ButtonObjects3Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35336972);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Reset_Timer"), gdjs.MainGame2Code.GDReset_9595TimerObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects3[i].setString("3");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects3[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDReset_9595TimerObjects3[i].getWidth()) / 2));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ResetTimer.wav", false, 30, 0.8);
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 2, 0.08, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGame2Code.eventsList58(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDReset_95959595LeaderboardObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35341884);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGame2Code.GDReset_9595ButtonObjects2);
/* Reuse gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2 */
{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595ButtonObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Leaderboard");
}{for(var i = 0, len = gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i].setPlaceholder("Add Name");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[i].hide();
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDLeaderboard_95959595SubmitObjects2Objects = Hashtable.newFrom({"Leaderboard_Submit": gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2});
gdjs.MainGame2Code.eventsList60 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35344180);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "MenuButtomPress.wav", false, 60, 0.8);
}{for(var i = 0, len = gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[i].getWidth()) / 2));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i].getWidth()) / 2));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i].isFocused() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[k] = gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i].getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[k] = gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[i].hide(false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDLeaderboard_95959595SubmitObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[k] = gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35347620);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2);
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.MainGame2Code.GDscoreObjects2);
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "05b26c61-c77e-4bad-b074-3f3060d6db57", (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGame2Code.GDscoreObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGame2Code.GDscoreObjects2[0].getVariables()).getFromIndex(0))), (( gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length === 0 ) ? "" :gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2[0].getText()));
}{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "05b26c61-c77e-4bad-b074-3f3060d6db57", true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.leaderboards.isLeaderboardViewLoaded();
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Death");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Leaderboard");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Leaderboard");
}}

}


};gdjs.MainGame2Code.eventsList61 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35330476);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Reset");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Leaderboard"));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList59(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Leaderboard");
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList60(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList62 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Reset_Timer"), gdjs.MainGame2Code.GDReset_9595TimerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDReset_9595TimerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDReset_9595TimerObjects2[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects1Objects) <= 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainGame2Code.GDPlayerObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDHelpIconObjects3Objects = Hashtable.newFrom({"HelpIcon": gdjs.MainGame2Code.GDHelpIconObjects3});
gdjs.MainGame2Code.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"), true);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "PauseLayer");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "music.wav", false, 15, 0.8);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"), false);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "PauseLayer");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "music.wav", false, 15, 1.1);
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDHelpIconObjects2Objects = Hashtable.newFrom({"HelpIcon": gdjs.MainGame2Code.GDHelpIconObjects2});
gdjs.MainGame2Code.eventsList64 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"), true);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "PauseLayer");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "music.wav", false, 15, 0.8);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"), false);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "PauseLayer");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "music.wav", false, 15, 1.1);
}}

}


};gdjs.MainGame2Code.eventsList65 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("HelpIcon"), gdjs.MainGame2Code.GDHelpIconObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDHelpIconObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35352076);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}
{ //Subevents
gdjs.MainGame2Code.eventsList63(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HelpIcon"), gdjs.MainGame2Code.GDHelpIconObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDHelpIconObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35354612);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "StartMenu", false);
}
{ //Subevents
gdjs.MainGame2Code.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList66 = function(runtimeScene) {

{

/* Reuse gdjs.MainGame2Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDPlayerObjects2Objects) > 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects2Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGame2Code.GDUpgradeIconsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects1Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGame2Code.GDUpgradeIconsObjects1});
gdjs.MainGame2Code.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradeIconsObjects1, gdjs.MainGame2Code.GDUpgradeIconsObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradeIconsObjects2[i].isCurrentAnimationName("HealthUp") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradeIconsObjects2[k] = gdjs.MainGame2Code.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects2[i].setString("+Max Health");
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradeIconsObjects1, gdjs.MainGame2Code.GDUpgradeIconsObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradeIconsObjects2[i].isCurrentAnimationName("FireRate") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradeIconsObjects2[k] = gdjs.MainGame2Code.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects2[i].setString("+Fire Rate");
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradeIconsObjects1, gdjs.MainGame2Code.GDUpgradeIconsObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradeIconsObjects2[i].isCurrentAnimationName("Armor") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradeIconsObjects2[k] = gdjs.MainGame2Code.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects2[i].setString("+Defense");
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradeIconsObjects1, gdjs.MainGame2Code.GDUpgradeIconsObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradeIconsObjects2[i].isCurrentAnimationName("Power") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradeIconsObjects2[k] = gdjs.MainGame2Code.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects2[i].setString("+Attack Power");
}
}}

}


{

gdjs.copyArray(gdjs.MainGame2Code.GDUpgradeIconsObjects1, gdjs.MainGame2Code.GDUpgradeIconsObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDUpgradeIconsObjects2[i].isCurrentAnimationName("Speed") ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDUpgradeIconsObjects2[k] = gdjs.MainGame2Code.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects2[i].setString("+Move Speed");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects1[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDUpgrade_9595TextObjects1[i].getWidth()) / 2),(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2) - ((gdjs.MainGame2Code.GDUpgrade_9595TextObjects1[i].getHeight()) / 2));
}
}}

}


};gdjs.MainGame2Code.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.MainGame2Code.GDUpgradeIconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGame2Code.GDUpgrade_9595TextObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDUpgrade_9595TextObjects2[i].setString(" ");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.MainGame2Code.GDUpgradeIconsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDUpgradeIconsObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList69 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Darkening"), gdjs.MainGame2Code.GDDarkeningObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDDarkeningObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDDarkeningObjects2[i].setOpacity(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MainGame2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainGame2Code.GDPlayerObjects2[i].getVariableNumber(gdjs.MainGame2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.MainGame2Code.GDPlayerObjects2[k] = gdjs.MainGame2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainGame2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList66(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "PauseLayer");
if (isConditionTrue_0) {

{ //Subevents
gdjs.MainGame2Code.eventsList68(runtimeScene);} //End of subevents
}

}


};gdjs.MainGame2Code.eventsList70 = function(runtimeScene) {

};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects2Objects = Hashtable.newFrom({"GrassBorder": gdjs.MainGame2Code.GDGrassBorderObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects2Objects = Hashtable.newFrom({"GrassBorder": gdjs.MainGame2Code.GDGrassBorderObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects2Objects = Hashtable.newFrom({"GrassBorder2": gdjs.MainGame2Code.GDGrassBorder2Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects2Objects = Hashtable.newFrom({"GrassBorder2": gdjs.MainGame2Code.GDGrassBorder2Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects = Hashtable.newFrom({"GrassBorder4": gdjs.MainGame2Code.GDGrassBorder4Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects2Objects = Hashtable.newFrom({"Tree": gdjs.MainGame2Code.GDTreeObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects2Objects = Hashtable.newFrom({"GrassBorder2": gdjs.MainGame2Code.GDGrassBorder2Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder3Objects2Objects = Hashtable.newFrom({"GrassBorder3": gdjs.MainGame2Code.GDGrassBorder3Objects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects2Objects = Hashtable.newFrom({"Tree": gdjs.MainGame2Code.GDTreeObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects2Objects = Hashtable.newFrom({"Tree": gdjs.MainGame2Code.GDTreeObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.MainGame2Code.GDWallObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.MainGame2Code.GDWallObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects1Objects = Hashtable.newFrom({"GrassBorder": gdjs.MainGame2Code.GDGrassBorderObjects1});
gdjs.MainGame2Code.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder"), gdjs.MainGame2Code.GDGrassBorderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder"), gdjs.MainGame2Code.GDGrassBorderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder2"), gdjs.MainGame2Code.GDGrassBorder2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder2"), gdjs.MainGame2Code.GDGrassBorder2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder4"), gdjs.MainGame2Code.GDGrassBorder4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGame2Code.GDImpObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder4Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGame2Code.GDSpiderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tree"), gdjs.MainGame2Code.GDTreeObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder2"), gdjs.MainGame2Code.GDGrassBorder2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder2Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder3"), gdjs.MainGame2Code.GDGrassBorder3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorder3Objects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tree"), gdjs.MainGame2Code.GDTreeObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tree"), gdjs.MainGame2Code.GDTreeObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.MainGame2Code.GDWallObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDWallObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGame2Code.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.MainGame2Code.GDWallObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostObjects2[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDWallObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GrassBorder"), gdjs.MainGame2Code.GDGrassBorderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGrassBorderObjects1Objects, false);
}
}}

}


};gdjs.MainGame2Code.mapOfEmptyGDGhostObjects = Hashtable.newFrom({"Ghost": []});
gdjs.MainGame2Code.mapOfEmptyGDSpiderObjects = Hashtable.newFrom({"Spider": []});
gdjs.MainGame2Code.mapOfEmptyGDImpObjects = Hashtable.newFrom({"Imp": []});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects = Hashtable.newFrom({"Spider": gdjs.MainGame2Code.GDSpiderObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects = Hashtable.newFrom({"Ghost": gdjs.MainGame2Code.GDGhostObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDpointsObjects2Objects = Hashtable.newFrom({"points": gdjs.MainGame2Code.GDpointsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDpointsObjects2Objects = Hashtable.newFrom({"points": gdjs.MainGame2Code.GDpointsObjects2});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects2Objects = Hashtable.newFrom({"Imp": gdjs.MainGame2Code.GDImpObjects2});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects2Objects = Hashtable.newFrom({"GoldenImp": gdjs.MainGame2Code.GDGoldenImpObjects2});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfEmptyGDpointsObjects = Hashtable.newFrom({"points": []});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects1Objects = Hashtable.newFrom({"GoldenImp": gdjs.MainGame2Code.GDGoldenImpObjects1});
gdjs.MainGame2Code.eventsList72 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.MainGame2Code.GDscoreObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDscoreObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDscoreObjects2[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDscoreObjects2[i].getVariables().getFromIndex(0)))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDGhostObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDSpiderObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDImpObjects) == 0;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.MainGame2Code.GDscoreObjects2);
gdjs.MainGame2Code.GDGhostObjects2.length = 0;

gdjs.MainGame2Code.GDImpObjects2.length = 0;

gdjs.MainGame2Code.GDSpiderObjects2.length = 0;

gdjs.MainGame2Code.GDpointsObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDSpiderObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDpointsObjects2Objects, 600, -(256), "");
}{for(var i = 0, len = gdjs.MainGame2Code.GDscoreObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDscoreObjects2[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGame2Code.GDscoreObjects2[i].getVariables().getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDscoreObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDscoreObjects2[i].returnVariable(gdjs.MainGame2Code.GDscoreObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDpointsObjects2Objects));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDImpObjects2Objects, gdjs.randomInRange(1, 763), gdjs.randomInRange(1, 425), "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("Rank 1");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("Rank 2");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("Rank 3");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("Rank 4");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 15;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("Rank 5");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 20;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("rank 6");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 20;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(35386388);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
gdjs.MainGame2Code.GDGoldenImpObjects2.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("rank 6");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects2Objects, 380, 188, "");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 25;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects2[i].getBehavior("Animation").setAnimationName("rank 7");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GoldenImp"), gdjs.MainGame2Code.GDGoldenImpObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDGoldenImpObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGoldenImpObjects2[i].getBehavior("Resizable").setSize(100, 100);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfEmptyGDpointsObjects) > 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rank"), gdjs.MainGame2Code.GDRankObjects1);
gdjs.MainGame2Code.GDGoldenImpObjects1.length = 0;

{for(var i = 0, len = gdjs.MainGame2Code.GDRankObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDRankObjects1[i].getBehavior("Animation").setAnimationName("Rank 8");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGoldenImpObjects1Objects, 380, 188, "");
}}

}


};gdjs.MainGame2Code.eventsList73 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("crossair"), gdjs.MainGame2Code.GDcrossairObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDcrossairObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDcrossairObjects2[i].setPosition((( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointX("")),(( gdjs.MainGame2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.MainGame2Code.GDPlayerObjects2[0].getPointY("")));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("crossair"), gdjs.MainGame2Code.GDcrossairObjects2);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.MainGame2Code.GDcrossairObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDcrossairObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AimingJoystick"), gdjs.MainGame2Code.GDAimingJoystickObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDAimingJoystickObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDAimingJoystickObjects1[i].getBehavior("Resizable").setSize(725, 725);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDAimingJoystickObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDAimingJoystickObjects1[i].setPosition(383,208);
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDAimingJoystickObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDAimingJoystickObjects1[i].hide();
}
}}

}


};gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects1Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGame2Code.GDGhostOrbObjects1});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects1ObjectsGDgdjs_9546MainGame2Code_9546GDTree2Objects1ObjectsGDgdjs_9546MainGame2Code_9546GDWallObjects1Objects = Hashtable.newFrom({"Tree": gdjs.MainGame2Code.GDTreeObjects1, "Tree2": gdjs.MainGame2Code.GDTree2Objects1, "Wall": gdjs.MainGame2Code.GDWallObjects1});
gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTree2Objects1Objects = Hashtable.newFrom({"Tree2": gdjs.MainGame2Code.GDTree2Objects1});
gdjs.MainGame2Code.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "default";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


};gdjs.MainGame2Code.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "john";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("4.png");
}
}}

}


};gdjs.MainGame2Code.eventsList76 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "Suspectguy";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("suspectguy");
}
}}

}


};gdjs.MainGame2Code.eventsList77 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "knight";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("knight");
}
}}

}


};gdjs.MainGame2Code.eventsList78 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "Buisnessman";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects3);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].getBehavior("Animation").setAnimationName("Player");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects3[i].getBehavior("Resizable").setSize(30, 30);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "knight";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("knight");
}
}}

}


};gdjs.MainGame2Code.eventsList79 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "sigma";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("sigma");
}
}}

}


};gdjs.MainGame2Code.eventsList80 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crossair"), gdjs.MainGame2Code.GDcrossairObjects2);
{for(var i = 0, len = gdjs.MainGame2Code.GDcrossairObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDcrossairObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "Layer", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "Layer", 0));
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDcrossairObjects2.length ;i < len;++i) {
    gdjs.MainGame2Code.GDcrossairObjects2[i].setLayer("Layer");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(2)) == "coco";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGame2Code.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGame2Code.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("coco");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDBulletObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDBulletObjects1[i].getBehavior("Animation").setAnimationName("egg");
}
}{for(var i = 0, len = gdjs.MainGame2Code.GDGunObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGunObjects1[i].getBehavior("Animation").setAnimationName("void");
}
}}

}


};gdjs.MainGame2Code.eventsList81 = function(runtimeScene) {

{


gdjs.MainGame2Code.eventsList74(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList75(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList76(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList77(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList78(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList79(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList80(runtimeScene);
}


};gdjs.MainGame2Code.eventsList82 = function(runtimeScene) {

{


gdjs.MainGame2Code.eventsList2(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList5(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList15(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList19(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList38(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList52(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList53(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList62(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList69(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList70(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainGame2Code.GDPlayerObjects1.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainGame2Code.GDPlayerObjects1.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MovementJoystick"), gdjs.MainGame2Code.GDMovementJoystickObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDMovementJoystickObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDMovementJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.MainGame2Code.GDPlayerObjects1.length !== 0 ? gdjs.MainGame2Code.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{


gdjs.MainGame2Code.eventsList71(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList72(runtimeScene);
}


{


gdjs.MainGame2Code.eventsList73(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crossair"), gdjs.MainGame2Code.GDcrossairObjects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDcrossairObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDcrossairObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGame2Code.GDGhostOrbObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree"), gdjs.MainGame2Code.GDTreeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.MainGame2Code.GDTree2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.MainGame2Code.GDWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDGhostOrbObjects1Objects, gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTreeObjects1ObjectsGDgdjs_9546MainGame2Code_9546GDTree2Objects1ObjectsGDgdjs_9546MainGame2Code_9546GDWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MainGame2Code.GDGhostOrbObjects1 */
{for(var i = 0, len = gdjs.MainGame2Code.GDGhostOrbObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDGhostOrbObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainGame2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.MainGame2Code.GDTree2Objects1);
{for(var i = 0, len = gdjs.MainGame2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainGame2Code.GDPlayerObjects1[i].separateFromObjectsList(gdjs.MainGame2Code.mapOfGDgdjs_9546MainGame2Code_9546GDTree2Objects1Objects, false);
}
}}

}


{


gdjs.MainGame2Code.eventsList81(runtimeScene);
}


};

gdjs.MainGame2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainGame2Code.GDRoomTrapsObjects1.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects2.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects3.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects4.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects5.length = 0;
gdjs.MainGame2Code.GDRoomTrapsObjects6.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects1.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects2.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects3.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects4.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects5.length = 0;
gdjs.MainGame2Code.GDRoomDoorsObjects6.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects1.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects2.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects3.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects4.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects5.length = 0;
gdjs.MainGame2Code.GDRoomFloorObjects6.length = 0;
gdjs.MainGame2Code.GDRoomObjects1.length = 0;
gdjs.MainGame2Code.GDRoomObjects2.length = 0;
gdjs.MainGame2Code.GDRoomObjects3.length = 0;
gdjs.MainGame2Code.GDRoomObjects4.length = 0;
gdjs.MainGame2Code.GDRoomObjects5.length = 0;
gdjs.MainGame2Code.GDRoomObjects6.length = 0;
gdjs.MainGame2Code.GDPlayerObjects1.length = 0;
gdjs.MainGame2Code.GDPlayerObjects2.length = 0;
gdjs.MainGame2Code.GDPlayerObjects3.length = 0;
gdjs.MainGame2Code.GDPlayerObjects4.length = 0;
gdjs.MainGame2Code.GDPlayerObjects5.length = 0;
gdjs.MainGame2Code.GDPlayerObjects6.length = 0;
gdjs.MainGame2Code.GDGunObjects1.length = 0;
gdjs.MainGame2Code.GDGunObjects2.length = 0;
gdjs.MainGame2Code.GDGunObjects3.length = 0;
gdjs.MainGame2Code.GDGunObjects4.length = 0;
gdjs.MainGame2Code.GDGunObjects5.length = 0;
gdjs.MainGame2Code.GDGunObjects6.length = 0;
gdjs.MainGame2Code.GDImpObjects1.length = 0;
gdjs.MainGame2Code.GDImpObjects2.length = 0;
gdjs.MainGame2Code.GDImpObjects3.length = 0;
gdjs.MainGame2Code.GDImpObjects4.length = 0;
gdjs.MainGame2Code.GDImpObjects5.length = 0;
gdjs.MainGame2Code.GDImpObjects6.length = 0;
gdjs.MainGame2Code.GDSpiderObjects1.length = 0;
gdjs.MainGame2Code.GDSpiderObjects2.length = 0;
gdjs.MainGame2Code.GDSpiderObjects3.length = 0;
gdjs.MainGame2Code.GDSpiderObjects4.length = 0;
gdjs.MainGame2Code.GDSpiderObjects5.length = 0;
gdjs.MainGame2Code.GDSpiderObjects6.length = 0;
gdjs.MainGame2Code.GDGhostObjects1.length = 0;
gdjs.MainGame2Code.GDGhostObjects2.length = 0;
gdjs.MainGame2Code.GDGhostObjects3.length = 0;
gdjs.MainGame2Code.GDGhostObjects4.length = 0;
gdjs.MainGame2Code.GDGhostObjects5.length = 0;
gdjs.MainGame2Code.GDGhostObjects6.length = 0;
gdjs.MainGame2Code.GDGhostOrbObjects1.length = 0;
gdjs.MainGame2Code.GDGhostOrbObjects2.length = 0;
gdjs.MainGame2Code.GDGhostOrbObjects3.length = 0;
gdjs.MainGame2Code.GDGhostOrbObjects4.length = 0;
gdjs.MainGame2Code.GDGhostOrbObjects5.length = 0;
gdjs.MainGame2Code.GDGhostOrbObjects6.length = 0;
gdjs.MainGame2Code.GDBulletObjects1.length = 0;
gdjs.MainGame2Code.GDBulletObjects2.length = 0;
gdjs.MainGame2Code.GDBulletObjects3.length = 0;
gdjs.MainGame2Code.GDBulletObjects4.length = 0;
gdjs.MainGame2Code.GDBulletObjects5.length = 0;
gdjs.MainGame2Code.GDBulletObjects6.length = 0;
gdjs.MainGame2Code.GDUpgradeTextObjects1.length = 0;
gdjs.MainGame2Code.GDUpgradeTextObjects2.length = 0;
gdjs.MainGame2Code.GDUpgradeTextObjects3.length = 0;
gdjs.MainGame2Code.GDUpgradeTextObjects4.length = 0;
gdjs.MainGame2Code.GDUpgradeTextObjects5.length = 0;
gdjs.MainGame2Code.GDUpgradeTextObjects6.length = 0;
gdjs.MainGame2Code.GDEnemyDamageTextObjects1.length = 0;
gdjs.MainGame2Code.GDEnemyDamageTextObjects2.length = 0;
gdjs.MainGame2Code.GDEnemyDamageTextObjects3.length = 0;
gdjs.MainGame2Code.GDEnemyDamageTextObjects4.length = 0;
gdjs.MainGame2Code.GDEnemyDamageTextObjects5.length = 0;
gdjs.MainGame2Code.GDEnemyDamageTextObjects6.length = 0;
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects1.length = 0;
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects2.length = 0;
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects3.length = 0;
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects4.length = 0;
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects5.length = 0;
gdjs.MainGame2Code.GDParticle_9595RecoilDustObjects6.length = 0;
gdjs.MainGame2Code.GDParticle_9595DashObjects1.length = 0;
gdjs.MainGame2Code.GDParticle_9595DashObjects2.length = 0;
gdjs.MainGame2Code.GDParticle_9595DashObjects3.length = 0;
gdjs.MainGame2Code.GDParticle_9595DashObjects4.length = 0;
gdjs.MainGame2Code.GDParticle_9595DashObjects5.length = 0;
gdjs.MainGame2Code.GDParticle_9595DashObjects6.length = 0;
gdjs.MainGame2Code.GDParticle_9595DeathObjects1.length = 0;
gdjs.MainGame2Code.GDParticle_9595DeathObjects2.length = 0;
gdjs.MainGame2Code.GDParticle_9595DeathObjects3.length = 0;
gdjs.MainGame2Code.GDParticle_9595DeathObjects4.length = 0;
gdjs.MainGame2Code.GDParticle_9595DeathObjects5.length = 0;
gdjs.MainGame2Code.GDParticle_9595DeathObjects6.length = 0;
gdjs.MainGame2Code.GDHealthBarObjects1.length = 0;
gdjs.MainGame2Code.GDHealthBarObjects2.length = 0;
gdjs.MainGame2Code.GDHealthBarObjects3.length = 0;
gdjs.MainGame2Code.GDHealthBarObjects4.length = 0;
gdjs.MainGame2Code.GDHealthBarObjects5.length = 0;
gdjs.MainGame2Code.GDHealthBarObjects6.length = 0;
gdjs.MainGame2Code.GDDebugObjects1.length = 0;
gdjs.MainGame2Code.GDDebugObjects2.length = 0;
gdjs.MainGame2Code.GDDebugObjects3.length = 0;
gdjs.MainGame2Code.GDDebugObjects4.length = 0;
gdjs.MainGame2Code.GDDebugObjects5.length = 0;
gdjs.MainGame2Code.GDDebugObjects6.length = 0;
gdjs.MainGame2Code.GDUpgradeIconsObjects1.length = 0;
gdjs.MainGame2Code.GDUpgradeIconsObjects2.length = 0;
gdjs.MainGame2Code.GDUpgradeIconsObjects3.length = 0;
gdjs.MainGame2Code.GDUpgradeIconsObjects4.length = 0;
gdjs.MainGame2Code.GDUpgradeIconsObjects5.length = 0;
gdjs.MainGame2Code.GDUpgradeIconsObjects6.length = 0;
gdjs.MainGame2Code.GDUpgradesObjects1.length = 0;
gdjs.MainGame2Code.GDUpgradesObjects2.length = 0;
gdjs.MainGame2Code.GDUpgradesObjects3.length = 0;
gdjs.MainGame2Code.GDUpgradesObjects4.length = 0;
gdjs.MainGame2Code.GDUpgradesObjects5.length = 0;
gdjs.MainGame2Code.GDUpgradesObjects6.length = 0;
gdjs.MainGame2Code.GDTotalPointsCountObjects1.length = 0;
gdjs.MainGame2Code.GDTotalPointsCountObjects2.length = 0;
gdjs.MainGame2Code.GDTotalPointsCountObjects3.length = 0;
gdjs.MainGame2Code.GDTotalPointsCountObjects4.length = 0;
gdjs.MainGame2Code.GDTotalPointsCountObjects5.length = 0;
gdjs.MainGame2Code.GDTotalPointsCountObjects6.length = 0;
gdjs.MainGame2Code.GDTotalPointsObjects1.length = 0;
gdjs.MainGame2Code.GDTotalPointsObjects2.length = 0;
gdjs.MainGame2Code.GDTotalPointsObjects3.length = 0;
gdjs.MainGame2Code.GDTotalPointsObjects4.length = 0;
gdjs.MainGame2Code.GDTotalPointsObjects5.length = 0;
gdjs.MainGame2Code.GDTotalPointsObjects6.length = 0;
gdjs.MainGame2Code.GDDangerLevelCountObjects1.length = 0;
gdjs.MainGame2Code.GDDangerLevelCountObjects2.length = 0;
gdjs.MainGame2Code.GDDangerLevelCountObjects3.length = 0;
gdjs.MainGame2Code.GDDangerLevelCountObjects4.length = 0;
gdjs.MainGame2Code.GDDangerLevelCountObjects5.length = 0;
gdjs.MainGame2Code.GDDangerLevelCountObjects6.length = 0;
gdjs.MainGame2Code.GDDangerLevelObjects1.length = 0;
gdjs.MainGame2Code.GDDangerLevelObjects2.length = 0;
gdjs.MainGame2Code.GDDangerLevelObjects3.length = 0;
gdjs.MainGame2Code.GDDangerLevelObjects4.length = 0;
gdjs.MainGame2Code.GDDangerLevelObjects5.length = 0;
gdjs.MainGame2Code.GDDangerLevelObjects6.length = 0;
gdjs.MainGame2Code.GDPick_9595UpsObjects1.length = 0;
gdjs.MainGame2Code.GDPick_9595UpsObjects2.length = 0;
gdjs.MainGame2Code.GDPick_9595UpsObjects3.length = 0;
gdjs.MainGame2Code.GDPick_9595UpsObjects4.length = 0;
gdjs.MainGame2Code.GDPick_9595UpsObjects5.length = 0;
gdjs.MainGame2Code.GDPick_9595UpsObjects6.length = 0;
gdjs.MainGame2Code.GDReset_9595TimerObjects1.length = 0;
gdjs.MainGame2Code.GDReset_9595TimerObjects2.length = 0;
gdjs.MainGame2Code.GDReset_9595TimerObjects3.length = 0;
gdjs.MainGame2Code.GDReset_9595TimerObjects4.length = 0;
gdjs.MainGame2Code.GDReset_9595TimerObjects5.length = 0;
gdjs.MainGame2Code.GDReset_9595TimerObjects6.length = 0;
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects1.length = 0;
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects2.length = 0;
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects3.length = 0;
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects4.length = 0;
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects5.length = 0;
gdjs.MainGame2Code.GDLeaderboard_9595SubmitObjects6.length = 0;
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects1.length = 0;
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects2.length = 0;
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects3.length = 0;
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects4.length = 0;
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects5.length = 0;
gdjs.MainGame2Code.GDReset_9595LeaderboardObjects6.length = 0;
gdjs.MainGame2Code.GDReset_9595ButtonObjects1.length = 0;
gdjs.MainGame2Code.GDReset_9595ButtonObjects2.length = 0;
gdjs.MainGame2Code.GDReset_9595ButtonObjects3.length = 0;
gdjs.MainGame2Code.GDReset_9595ButtonObjects4.length = 0;
gdjs.MainGame2Code.GDReset_9595ButtonObjects5.length = 0;
gdjs.MainGame2Code.GDReset_9595ButtonObjects6.length = 0;
gdjs.MainGame2Code.GDDarkeningObjects1.length = 0;
gdjs.MainGame2Code.GDDarkeningObjects2.length = 0;
gdjs.MainGame2Code.GDDarkeningObjects3.length = 0;
gdjs.MainGame2Code.GDDarkeningObjects4.length = 0;
gdjs.MainGame2Code.GDDarkeningObjects5.length = 0;
gdjs.MainGame2Code.GDDarkeningObjects6.length = 0;
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects1.length = 0;
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects2.length = 0;
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects3.length = 0;
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects4.length = 0;
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects5.length = 0;
gdjs.MainGame2Code.GDLeaderboardName_9595InputObjects6.length = 0;
gdjs.MainGame2Code.GDPause_9595TextObjects1.length = 0;
gdjs.MainGame2Code.GDPause_9595TextObjects2.length = 0;
gdjs.MainGame2Code.GDPause_9595TextObjects3.length = 0;
gdjs.MainGame2Code.GDPause_9595TextObjects4.length = 0;
gdjs.MainGame2Code.GDPause_9595TextObjects5.length = 0;
gdjs.MainGame2Code.GDPause_9595TextObjects6.length = 0;
gdjs.MainGame2Code.GDUpgrade_9595TextObjects1.length = 0;
gdjs.MainGame2Code.GDUpgrade_9595TextObjects2.length = 0;
gdjs.MainGame2Code.GDUpgrade_9595TextObjects3.length = 0;
gdjs.MainGame2Code.GDUpgrade_9595TextObjects4.length = 0;
gdjs.MainGame2Code.GDUpgrade_9595TextObjects5.length = 0;
gdjs.MainGame2Code.GDUpgrade_9595TextObjects6.length = 0;
gdjs.MainGame2Code.GDHelpIconObjects1.length = 0;
gdjs.MainGame2Code.GDHelpIconObjects2.length = 0;
gdjs.MainGame2Code.GDHelpIconObjects3.length = 0;
gdjs.MainGame2Code.GDHelpIconObjects4.length = 0;
gdjs.MainGame2Code.GDHelpIconObjects5.length = 0;
gdjs.MainGame2Code.GDHelpIconObjects6.length = 0;
gdjs.MainGame2Code.GDMobileCoveringObjects1.length = 0;
gdjs.MainGame2Code.GDMobileCoveringObjects2.length = 0;
gdjs.MainGame2Code.GDMobileCoveringObjects3.length = 0;
gdjs.MainGame2Code.GDMobileCoveringObjects4.length = 0;
gdjs.MainGame2Code.GDMobileCoveringObjects5.length = 0;
gdjs.MainGame2Code.GDMobileCoveringObjects6.length = 0;
gdjs.MainGame2Code.GDMovementJoystickObjects1.length = 0;
gdjs.MainGame2Code.GDMovementJoystickObjects2.length = 0;
gdjs.MainGame2Code.GDMovementJoystickObjects3.length = 0;
gdjs.MainGame2Code.GDMovementJoystickObjects4.length = 0;
gdjs.MainGame2Code.GDMovementJoystickObjects5.length = 0;
gdjs.MainGame2Code.GDMovementJoystickObjects6.length = 0;
gdjs.MainGame2Code.GDAimingJoystickObjects1.length = 0;
gdjs.MainGame2Code.GDAimingJoystickObjects2.length = 0;
gdjs.MainGame2Code.GDAimingJoystickObjects3.length = 0;
gdjs.MainGame2Code.GDAimingJoystickObjects4.length = 0;
gdjs.MainGame2Code.GDAimingJoystickObjects5.length = 0;
gdjs.MainGame2Code.GDAimingJoystickObjects6.length = 0;
gdjs.MainGame2Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.MainGame2Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.MainGame2Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.MainGame2Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.MainGame2Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.MainGame2Code.GDNewTiledSpriteObjects6.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects1.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects2.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects3.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects4.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects5.length = 0;
gdjs.MainGame2Code.GDGrassBorderObjects6.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects1.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects2.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects3.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects4.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects5.length = 0;
gdjs.MainGame2Code.GDGrassBorder2Objects6.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects1.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects2.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects3.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects4.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects5.length = 0;
gdjs.MainGame2Code.GDGrassBorder4Objects6.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects1.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects2.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects3.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects4.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects5.length = 0;
gdjs.MainGame2Code.GDGrassBorder3Objects6.length = 0;
gdjs.MainGame2Code.GDTreeObjects1.length = 0;
gdjs.MainGame2Code.GDTreeObjects2.length = 0;
gdjs.MainGame2Code.GDTreeObjects3.length = 0;
gdjs.MainGame2Code.GDTreeObjects4.length = 0;
gdjs.MainGame2Code.GDTreeObjects5.length = 0;
gdjs.MainGame2Code.GDTreeObjects6.length = 0;
gdjs.MainGame2Code.GDWallObjects1.length = 0;
gdjs.MainGame2Code.GDWallObjects2.length = 0;
gdjs.MainGame2Code.GDWallObjects3.length = 0;
gdjs.MainGame2Code.GDWallObjects4.length = 0;
gdjs.MainGame2Code.GDWallObjects5.length = 0;
gdjs.MainGame2Code.GDWallObjects6.length = 0;
gdjs.MainGame2Code.GDNewTextObjects1.length = 0;
gdjs.MainGame2Code.GDNewTextObjects2.length = 0;
gdjs.MainGame2Code.GDNewTextObjects3.length = 0;
gdjs.MainGame2Code.GDNewTextObjects4.length = 0;
gdjs.MainGame2Code.GDNewTextObjects5.length = 0;
gdjs.MainGame2Code.GDNewTextObjects6.length = 0;
gdjs.MainGame2Code.GDscoreObjects1.length = 0;
gdjs.MainGame2Code.GDscoreObjects2.length = 0;
gdjs.MainGame2Code.GDscoreObjects3.length = 0;
gdjs.MainGame2Code.GDscoreObjects4.length = 0;
gdjs.MainGame2Code.GDscoreObjects5.length = 0;
gdjs.MainGame2Code.GDscoreObjects6.length = 0;
gdjs.MainGame2Code.GDpointsObjects1.length = 0;
gdjs.MainGame2Code.GDpointsObjects2.length = 0;
gdjs.MainGame2Code.GDpointsObjects3.length = 0;
gdjs.MainGame2Code.GDpointsObjects4.length = 0;
gdjs.MainGame2Code.GDpointsObjects5.length = 0;
gdjs.MainGame2Code.GDpointsObjects6.length = 0;
gdjs.MainGame2Code.GDNewPanelSpriteObjects1.length = 0;
gdjs.MainGame2Code.GDNewPanelSpriteObjects2.length = 0;
gdjs.MainGame2Code.GDNewPanelSpriteObjects3.length = 0;
gdjs.MainGame2Code.GDNewPanelSpriteObjects4.length = 0;
gdjs.MainGame2Code.GDNewPanelSpriteObjects5.length = 0;
gdjs.MainGame2Code.GDNewPanelSpriteObjects6.length = 0;
gdjs.MainGame2Code.GDSpawnPointObjects1.length = 0;
gdjs.MainGame2Code.GDSpawnPointObjects2.length = 0;
gdjs.MainGame2Code.GDSpawnPointObjects3.length = 0;
gdjs.MainGame2Code.GDSpawnPointObjects4.length = 0;
gdjs.MainGame2Code.GDSpawnPointObjects5.length = 0;
gdjs.MainGame2Code.GDSpawnPointObjects6.length = 0;
gdjs.MainGame2Code.GDRankObjects1.length = 0;
gdjs.MainGame2Code.GDRankObjects2.length = 0;
gdjs.MainGame2Code.GDRankObjects3.length = 0;
gdjs.MainGame2Code.GDRankObjects4.length = 0;
gdjs.MainGame2Code.GDRankObjects5.length = 0;
gdjs.MainGame2Code.GDRankObjects6.length = 0;
gdjs.MainGame2Code.GDcrossairObjects1.length = 0;
gdjs.MainGame2Code.GDcrossairObjects2.length = 0;
gdjs.MainGame2Code.GDcrossairObjects3.length = 0;
gdjs.MainGame2Code.GDcrossairObjects4.length = 0;
gdjs.MainGame2Code.GDcrossairObjects5.length = 0;
gdjs.MainGame2Code.GDcrossairObjects6.length = 0;
gdjs.MainGame2Code.GDTree2Objects1.length = 0;
gdjs.MainGame2Code.GDTree2Objects2.length = 0;
gdjs.MainGame2Code.GDTree2Objects3.length = 0;
gdjs.MainGame2Code.GDTree2Objects4.length = 0;
gdjs.MainGame2Code.GDTree2Objects5.length = 0;
gdjs.MainGame2Code.GDTree2Objects6.length = 0;
gdjs.MainGame2Code.GDgrass2Objects1.length = 0;
gdjs.MainGame2Code.GDgrass2Objects2.length = 0;
gdjs.MainGame2Code.GDgrass2Objects3.length = 0;
gdjs.MainGame2Code.GDgrass2Objects4.length = 0;
gdjs.MainGame2Code.GDgrass2Objects5.length = 0;
gdjs.MainGame2Code.GDgrass2Objects6.length = 0;
gdjs.MainGame2Code.GDgrass1Objects1.length = 0;
gdjs.MainGame2Code.GDgrass1Objects2.length = 0;
gdjs.MainGame2Code.GDgrass1Objects3.length = 0;
gdjs.MainGame2Code.GDgrass1Objects4.length = 0;
gdjs.MainGame2Code.GDgrass1Objects5.length = 0;
gdjs.MainGame2Code.GDgrass1Objects6.length = 0;
gdjs.MainGame2Code.GDGroundObjects1.length = 0;
gdjs.MainGame2Code.GDGroundObjects2.length = 0;
gdjs.MainGame2Code.GDGroundObjects3.length = 0;
gdjs.MainGame2Code.GDGroundObjects4.length = 0;
gdjs.MainGame2Code.GDGroundObjects5.length = 0;
gdjs.MainGame2Code.GDGroundObjects6.length = 0;
gdjs.MainGame2Code.GDGoldenImpObjects1.length = 0;
gdjs.MainGame2Code.GDGoldenImpObjects2.length = 0;
gdjs.MainGame2Code.GDGoldenImpObjects3.length = 0;
gdjs.MainGame2Code.GDGoldenImpObjects4.length = 0;
gdjs.MainGame2Code.GDGoldenImpObjects5.length = 0;
gdjs.MainGame2Code.GDGoldenImpObjects6.length = 0;

gdjs.MainGame2Code.eventsList82(runtimeScene);

return;

}

gdjs['MainGame2Code'] = gdjs.MainGame2Code;
