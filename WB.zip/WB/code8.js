gdjs.ShopCode = {};
gdjs.ShopCode.GDBuyingAmmoObjects1= [];
gdjs.ShopCode.GDBuyingAmmoObjects2= [];
gdjs.ShopCode.GDBuyingAmmoObjects3= [];
gdjs.ShopCode.GDX10Objects1= [];
gdjs.ShopCode.GDX10Objects2= [];
gdjs.ShopCode.GDX10Objects3= [];
gdjs.ShopCode.GDUiBgObjects1= [];
gdjs.ShopCode.GDUiBgObjects2= [];
gdjs.ShopCode.GDUiBgObjects3= [];
gdjs.ShopCode.GDCoinObjects1= [];
gdjs.ShopCode.GDCoinObjects2= [];
gdjs.ShopCode.GDCoinObjects3= [];
gdjs.ShopCode.GDCounterObjects1= [];
gdjs.ShopCode.GDCounterObjects2= [];
gdjs.ShopCode.GDCounterObjects3= [];
gdjs.ShopCode.GDBackObjects1= [];
gdjs.ShopCode.GDBackObjects2= [];
gdjs.ShopCode.GDBackObjects3= [];
gdjs.ShopCode.GDUpgradeIconsObjects1= [];
gdjs.ShopCode.GDUpgradeIconsObjects2= [];
gdjs.ShopCode.GDUpgradeIconsObjects3= [];
gdjs.ShopCode.GDSpeedObjects1= [];
gdjs.ShopCode.GDSpeedObjects2= [];
gdjs.ShopCode.GDSpeedObjects3= [];
gdjs.ShopCode.GDFire_9595rateObjects1= [];
gdjs.ShopCode.GDFire_9595rateObjects2= [];
gdjs.ShopCode.GDFire_9595rateObjects3= [];
gdjs.ShopCode.GDDamageObjects1= [];
gdjs.ShopCode.GDDamageObjects2= [];
gdjs.ShopCode.GDDamageObjects3= [];
gdjs.ShopCode.GDArmorObjects1= [];
gdjs.ShopCode.GDArmorObjects2= [];
gdjs.ShopCode.GDArmorObjects3= [];
gdjs.ShopCode.GDHealthObjects1= [];
gdjs.ShopCode.GDHealthObjects2= [];
gdjs.ShopCode.GDHealthObjects3= [];
gdjs.ShopCode.GDSignObjects1= [];
gdjs.ShopCode.GDSignObjects2= [];
gdjs.ShopCode.GDSignObjects3= [];
gdjs.ShopCode.GDPrice_9595UpgradeObjects1= [];
gdjs.ShopCode.GDPrice_9595UpgradeObjects2= [];
gdjs.ShopCode.GDPrice_9595UpgradeObjects3= [];
gdjs.ShopCode.GDFreeTokensObjects1= [];
gdjs.ShopCode.GDFreeTokensObjects2= [];
gdjs.ShopCode.GDFreeTokensObjects3= [];
gdjs.ShopCode.GDNewSpriteObjects1= [];
gdjs.ShopCode.GDNewSpriteObjects2= [];
gdjs.ShopCode.GDNewSpriteObjects3= [];
gdjs.ShopCode.GDWarnTextUpsObjects1= [];
gdjs.ShopCode.GDWarnTextUpsObjects2= [];
gdjs.ShopCode.GDWarnTextUpsObjects3= [];


gdjs.ShopCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.ShopCode.GDBackObjects2);
gdjs.copyArray(runtimeScene.getObjects("WarnTextUps"), gdjs.ShopCode.GDWarnTextUpsObjects2);
{}{for(var i = 0, len = gdjs.ShopCode.GDWarnTextUpsObjects2.length ;i < len;++i) {
    gdjs.ShopCode.GDWarnTextUpsObjects2[i].getBehavior("Text").setText("les améliorations ne peuvent être obtenue qu'une apprès l'autre");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.ShopCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("WarnTextUps"), gdjs.ShopCode.GDWarnTextUpsObjects1);
{}{for(var i = 0, len = gdjs.ShopCode.GDWarnTextUpsObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDWarnTextUpsObjects1[i].getBehavior("Text").setText("The Upgrades can only be obtained one after the other");
}
}}

}


};gdjs.ShopCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.ShopCode.GDUpgradeIconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 150;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("Animation").getAnimationName() == "HealthUp" ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(150);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Tokens", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.ShopCode.GDUpgradeIconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 150;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("Animation").getAnimationName() == "Armor" ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(150);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Tokens", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.ShopCode.GDUpgradeIconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 150;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("Animation").getAnimationName() == "Power" ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(150);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Tokens", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.ShopCode.GDUpgradeIconsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 150;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("Animation").getAnimationName() == "FireRate" ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects2[k] = gdjs.ShopCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(150);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Tokens", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.ShopCode.GDUpgradeIconsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 150;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects1[i].getBehavior("Animation").getAnimationName() == "Speed" ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects1[k] = gdjs.ShopCode.GDUpgradeIconsObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDUpgradeIconsObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDUpgradeIconsObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDUpgradeIconsObjects1[k] = gdjs.ShopCode.GDUpgradeIconsObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDUpgradeIconsObjects1.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(150);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Tokens", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


};gdjs.ShopCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Counter"), gdjs.ShopCode.GDCounterObjects1);
{for(var i = 0, len = gdjs.ShopCode.GDCounterObjects1.length ;i < len;++i) {
    gdjs.ShopCode.GDCounterObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BuyingAmmo"), gdjs.ShopCode.GDBuyingAmmoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBuyingAmmoObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBuyingAmmoObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBuyingAmmoObjects1[k] = gdjs.ShopCode.GDBuyingAmmoObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBuyingAmmoObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(3);
}{runtimeScene.getGame().getVariables().getFromIndex(10).add(10);
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Bullet", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10))));
}{gdjs.evtTools.storage.writeStringInJSONFile("API", "Tokens", gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.input.showCursor(runtimeScene);
}}

}


{


gdjs.ShopCode.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.ShopCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDBackObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDBackObjects1[k] = gdjs.ShopCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainGame3", true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FreeTokens"), gdjs.ShopCode.GDFreeTokensObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDFreeTokensObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDFreeTokensObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDFreeTokensObjects1[k] = gdjs.ShopCode.GDFreeTokensObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDFreeTokensObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(100);
}}

}


{


gdjs.ShopCode.eventsList1(runtimeScene);
}


};

gdjs.ShopCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ShopCode.GDBuyingAmmoObjects1.length = 0;
gdjs.ShopCode.GDBuyingAmmoObjects2.length = 0;
gdjs.ShopCode.GDBuyingAmmoObjects3.length = 0;
gdjs.ShopCode.GDX10Objects1.length = 0;
gdjs.ShopCode.GDX10Objects2.length = 0;
gdjs.ShopCode.GDX10Objects3.length = 0;
gdjs.ShopCode.GDUiBgObjects1.length = 0;
gdjs.ShopCode.GDUiBgObjects2.length = 0;
gdjs.ShopCode.GDUiBgObjects3.length = 0;
gdjs.ShopCode.GDCoinObjects1.length = 0;
gdjs.ShopCode.GDCoinObjects2.length = 0;
gdjs.ShopCode.GDCoinObjects3.length = 0;
gdjs.ShopCode.GDCounterObjects1.length = 0;
gdjs.ShopCode.GDCounterObjects2.length = 0;
gdjs.ShopCode.GDCounterObjects3.length = 0;
gdjs.ShopCode.GDBackObjects1.length = 0;
gdjs.ShopCode.GDBackObjects2.length = 0;
gdjs.ShopCode.GDBackObjects3.length = 0;
gdjs.ShopCode.GDUpgradeIconsObjects1.length = 0;
gdjs.ShopCode.GDUpgradeIconsObjects2.length = 0;
gdjs.ShopCode.GDUpgradeIconsObjects3.length = 0;
gdjs.ShopCode.GDSpeedObjects1.length = 0;
gdjs.ShopCode.GDSpeedObjects2.length = 0;
gdjs.ShopCode.GDSpeedObjects3.length = 0;
gdjs.ShopCode.GDFire_9595rateObjects1.length = 0;
gdjs.ShopCode.GDFire_9595rateObjects2.length = 0;
gdjs.ShopCode.GDFire_9595rateObjects3.length = 0;
gdjs.ShopCode.GDDamageObjects1.length = 0;
gdjs.ShopCode.GDDamageObjects2.length = 0;
gdjs.ShopCode.GDDamageObjects3.length = 0;
gdjs.ShopCode.GDArmorObjects1.length = 0;
gdjs.ShopCode.GDArmorObjects2.length = 0;
gdjs.ShopCode.GDArmorObjects3.length = 0;
gdjs.ShopCode.GDHealthObjects1.length = 0;
gdjs.ShopCode.GDHealthObjects2.length = 0;
gdjs.ShopCode.GDHealthObjects3.length = 0;
gdjs.ShopCode.GDSignObjects1.length = 0;
gdjs.ShopCode.GDSignObjects2.length = 0;
gdjs.ShopCode.GDSignObjects3.length = 0;
gdjs.ShopCode.GDPrice_9595UpgradeObjects1.length = 0;
gdjs.ShopCode.GDPrice_9595UpgradeObjects2.length = 0;
gdjs.ShopCode.GDPrice_9595UpgradeObjects3.length = 0;
gdjs.ShopCode.GDFreeTokensObjects1.length = 0;
gdjs.ShopCode.GDFreeTokensObjects2.length = 0;
gdjs.ShopCode.GDFreeTokensObjects3.length = 0;
gdjs.ShopCode.GDNewSpriteObjects1.length = 0;
gdjs.ShopCode.GDNewSpriteObjects2.length = 0;
gdjs.ShopCode.GDNewSpriteObjects3.length = 0;
gdjs.ShopCode.GDWarnTextUpsObjects1.length = 0;
gdjs.ShopCode.GDWarnTextUpsObjects2.length = 0;
gdjs.ShopCode.GDWarnTextUpsObjects3.length = 0;

gdjs.ShopCode.eventsList2(runtimeScene);

return;

}

gdjs['ShopCode'] = gdjs.ShopCode;
